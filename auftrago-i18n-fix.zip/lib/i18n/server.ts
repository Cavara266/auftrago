import { cookies, headers } from "next/headers";

import {
  defaultLocale,
  normalizeLocale,
  type Locale,
} from "./config";

export async function getServerLocale(): Promise<Locale> {
  try {
    // 1. Wichtig: Sprache aus der aktuellen URL / Middleware hat Priorität.
    const headerStore = await headers();

    const headerLocale = headerStore.get("x-auftrag-locale");

    if (headerLocale) {
      return normalizeLocale(headerLocale);
    }

    // 2. Nur wenn kein URL-Locale-Header vorhanden ist:
    // gespeicherten Cookie verwenden.
    const cookieStore = await cookies();

    const saved = cookieStore.get("auftrag_locale")?.value;

    if (saved) {
      return normalizeLocale(saved);
    }

    return defaultLocale;
  } catch {
    return defaultLocale;
  }
}
