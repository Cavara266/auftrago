import { swissCities } from "@/data/seo-scale/swiss-cities";
import { seoServiceSlugs } from "@/data/seo-scale/service-slugs";

const BASE_URL = "https://www.auftrago.ch";

const CHUNK_SIZE = 50000;
const SEO_LIMIT = 50000000;

const intents = [
  "kosten",
  "preise",
  "offerte",
  "anbieter",
  "firma",
  "vergleich",
  "guenstig",
  "schnell",
  "professionell",
  "regional",
  "kurzfristig",
  "beratung",
  "service",
] as const;

const audiences = [
  "privat",
  "gewerbe",
  "verwaltung",
  "firma",
  "eigentuemer",
  "mieter",
  "buero",
  "immobilien",
] as const;

const modifiers = [
  "finden",
  "guenstig",
  "vergleichen",
  "anfragen",
  "buchen",
  "kosten",
  "preise",
  "offerte",
  "service",
  "experten",
  "anbieter",
  "regional",
  "professionell",
] as const;

const validCities = swissCities.filter(
  (city): city is typeof city & { slug: string } =>
    Boolean(city && typeof city.slug === "string" && city.slug.length > 0),
);

function xmlEscape(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&apos;");
}

function getSeoUrl(globalIndex: number): string | null {
  if (validCities.length === 0) {
    return null;
  }

  let n = globalIndex;

  const cityIndex = n % validCities.length;
  n = Math.floor(n / validCities.length);

  const serviceIndex = n % seoServiceSlugs.length;
  n = Math.floor(n / seoServiceSlugs.length);

  const modifierIndex = n % modifiers.length;
  n = Math.floor(n / modifiers.length);

  const audienceIndex = n % audiences.length;
  n = Math.floor(n / audiences.length);

  const intentIndex = n % intents.length;

  const citySlug = validCities[cityIndex]?.slug;
  const serviceSlug = seoServiceSlugs[serviceIndex];
  const intent = intents[intentIndex];
  const audience = audiences[audienceIndex];
  const modifier = modifiers[modifierIndex];

  if (
    !citySlug ||
    !serviceSlug ||
    !intent ||
    !audience ||
    !modifier
  ) {
    return null;
  }

  return `${BASE_URL}/seo/${serviceSlug}/${citySlug}/${intent}/${audience}/${modifier}`;
}

export async function GET(
  _request: Request,
  { params }: { params: { chunk: string } },
) {
  const chunk = Number(params.chunk);
  const maxChunks = Math.ceil(SEO_LIMIT / CHUNK_SIZE);

  if (
    !Number.isInteger(chunk) ||
    chunk < 1 ||
    chunk > maxChunks
  ) {
    return new Response("Sitemap not found", {
      status: 404,
    });
  }

  const start = (chunk - 1) * CHUNK_SIZE;
  const end = Math.min(start + CHUNK_SIZE, SEO_LIMIT);

  const urls: string[] = [];

  for (let index = start; index < end; index++) {
    const url = getSeoUrl(index);

    if (!url) continue;

    urls.push(
      `<url>` +
        `<loc>${xmlEscape(url)}</loc>` +
        `<changefreq>weekly</changefreq>` +
        `<priority>0.7</priority>` +
      `</url>`,
    );
  }

  const xml =
    `<?xml version="1.0" encoding="UTF-8"?>` +
    `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">` +
    urls.join("") +
    `</urlset>`;

  return new Response(xml, {
    status: 200,
    headers: {
      "Content-Type": "application/xml; charset=utf-8",
      "Cache-Control":
        "public, max-age=3600, s-maxage=86400, stale-while-revalidate=86400",
    },
  });
}
