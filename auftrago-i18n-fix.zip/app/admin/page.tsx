import Link from "next/link";
import AdminAutoRefresh from "@/components/admin/admin-auto-refresh";

import { prisma } from "@/lib/prisma";
import "./admin-dashboard.css";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const revalidate = 0;

function formatDate(date: Date) {
  return new Intl.DateTimeFormat("de-CH", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function formatMoney(amountInRappen: number, currency = "chf") {
  return new Intl.NumberFormat("de-CH", {
    style: "currency",
    currency: currency.toUpperCase(),
    minimumFractionDigits: 2,
  }).format(amountInRappen / 100);
}

function formatNumber(value: number) {
  return new Intl.NumberFormat("de-CH").format(value);
}

function percentage(value: number, total: number) {
  if (total <= 0) return 0;
  return Math.round((value / total) * 100);
}

function growth(current: number, previous: number) {
  if (previous <= 0) return current > 0 ? 100 : 0;
  return Math.round(((current - previous) / previous) * 100);
}

function startOfDay(date: Date) {
  const value = new Date(date);
  value.setHours(0, 0, 0, 0);
  return value;
}

function startOfMonth(date: Date) {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

function initials(value: string) {
  return value
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
}

function providerStatus(status: string) {
  if (status === "APPROVED") {
    return {
      label: "Genehmigt",
      className: "status-approved",
    };
  }

  if (status === "BLOCKED") {
    return {
      label: "Gesperrt",
      className: "status-blocked",
    };
  }

  return {
    label: "Ausstehend",
    className: "status-pending",
  };
}

function activityIcon(type: string) {
  if (type === "provider") return "P";
  if (type === "lead") return "L";
  if (type === "purchase") return "K";
  if (type === "payment") return "CHF";
  return "•";
}

export default async function AdminDashboardPage() {
  const now = new Date();
  const today = startOfDay(now);
  const monthStart = startOfMonth(now);
  const last7Days = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const previous7DaysStart = new Date(
    now.getTime() - 14 * 24 * 60 * 60 * 1000
  );
  const last30Days = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

  const [
    latestProviders,
    latestLeads,
    latestLeadPurchases,
    latestCreditPurchases,
    providerCount,
    pendingProviderCount,
    approvedProviderCount,
    blockedProviderCount,
    activeSubscriptionCount,
    trialSubscriptionCount,
    manualSubscriptionCount,
    paymentProblemSubscriptionCount,
    cancelledSubscriptionCount,
    noLeadAccessCount,
    providersToday,
    providersLast7,
    providersPrevious7,
    leadCount,
    leadsToday,
    leadsLast7,
    leadsPrevious7,
    leadPurchaseCount,
    leadPurchasesToday,
    leadPurchasesLast7,
    leadPurchasesPrevious7,
    paidCreditAggregate,
    revenueTodayAggregate,
    revenueMonthAggregate,
    revenueLast7Aggregate,
    revenuePrevious7Aggregate,
    leadCreditsAggregate,
    wonCount,
    contactedCount,
    offerSentCount,
    topRegions,
    topCategories,
    topProviders,
    revenueChartPurchases,
    latestFixedOrders,
    fixedOrderCount,
    openFixedOrderCount,
    reservedFixedOrderCount,
    soldFixedOrderCount,
    completedFixedOrderCount,
    fixedOrderRevenueAggregate,
    fixedOrderRevenueTodayAggregate,
    fixedOrderRevenueMonthAggregate,
  ] = await Promise.all([
    prisma.provider.findMany({
      orderBy: { createdAt: "desc" },
      take: 6,
      select: {
        id: true,
        companyName: true,
        contactName: true,
        region: true,
        credits: true,
        status: true,
        createdAt: true,
      },
    }),

    prisma.lead.findMany({
      orderBy: { createdAt: "desc" },
      take: 6,
      select: {
        id: true,
        title: true,
        region: true,
        category: true,
        price: true,
        createdAt: true,
        _count: {
          select: {
            purchases: true,
          },
        },
      },
    }),

    prisma.leadPurchase.findMany({
      orderBy: { createdAt: "desc" },
      take: 8,
      include: {
        provider: {
          select: {
            id: true,
            companyName: true,
          },
        },
        lead: {
          select: {
            id: true,
            title: true,
            region: true,
          },
        },
      },
    }),

    prisma.creditPurchase.findMany({
      where: {
        status: "paid",
      },
      orderBy: { createdAt: "desc" },
      take: 8,
      include: {
        provider: {
          select: {
            id: true,
            companyName: true,
          },
        },
      },
    }),

    prisma.provider.count(),
    prisma.provider.count({ where: { status: "PENDING" } }),
    prisma.provider.count({ where: { status: "APPROVED" } }),
    prisma.provider.count({ where: { status: "BLOCKED" } }),

    prisma.provider.count({
      where: {
        subscriptionExempt: false,
        subscriptionStatus: "ACTIVE",
      },
    }),

    prisma.provider.count({
      where: {
        subscriptionExempt: false,
        subscriptionStatus: "TRIALING",
      },
    }),

    prisma.provider.count({
      where: {
        subscriptionExempt: true,
      },
    }),

    prisma.provider.count({
      where: {
        subscriptionStatus: {
          in: ["PAST_DUE", "UNPAID", "INCOMPLETE"],
        },
      },
    }),

    prisma.provider.count({
      where: {
        OR: [
          {
            subscriptionStatus: {
              in: ["CANCELED", "CANCELLED"],
            },
          },
          {
            subscriptionCancelAtPeriodEnd: true,
          },
        ],
      },
    }),

    prisma.provider.count({
      where: {
        status: "APPROVED",
        subscriptionExempt: false,
        subscriptionStatus: {
          notIn: ["ACTIVE", "TRIALING"],
        },
      },
    }),

    prisma.provider.count({ where: { createdAt: { gte: today } } }),
    prisma.provider.count({ where: { createdAt: { gte: last7Days } } }),
    prisma.provider.count({
      where: {
        createdAt: {
          gte: previous7DaysStart,
          lt: last7Days,
        },
      },
    }),

    prisma.lead.count(),
    prisma.lead.count({ where: { createdAt: { gte: today } } }),
    prisma.lead.count({ where: { createdAt: { gte: last7Days } } }),
    prisma.lead.count({
      where: {
        createdAt: {
          gte: previous7DaysStart,
          lt: last7Days,
        },
      },
    }),

    prisma.leadPurchase.count(),
    prisma.leadPurchase.count({ where: { createdAt: { gte: today } } }),
    prisma.leadPurchase.count({ where: { createdAt: { gte: last7Days } } }),
    prisma.leadPurchase.count({
      where: {
        createdAt: {
          gte: previous7DaysStart,
          lt: last7Days,
        },
      },
    }),

    prisma.creditPurchase.aggregate({
      where: { status: "paid" },
      _sum: {
        amount: true,
        credits: true,
      },
      _count: {
        id: true,
      },
    }),

    prisma.creditPurchase.aggregate({
      where: {
        status: "paid",
        createdAt: {
          gte: today,
        },
      },
      _sum: {
        amount: true,
      },
    }),

    prisma.creditPurchase.aggregate({
      where: {
        status: "paid",
        createdAt: {
          gte: monthStart,
        },
      },
      _sum: {
        amount: true,
      },
    }),

    prisma.creditPurchase.aggregate({
      where: {
        status: "paid",
        createdAt: {
          gte: last7Days,
        },
      },
      _sum: {
        amount: true,
      },
    }),

    prisma.creditPurchase.aggregate({
      where: {
        status: "paid",
        createdAt: {
          gte: previous7DaysStart,
          lt: last7Days,
        },
      },
      _sum: {
        amount: true,
      },
    }),

    prisma.leadPurchase.aggregate({
      _sum: {
        price: true,
      },
    }),

    prisma.leadPurchase.count({
      where: {
        status: "WON",
      },
    }),

    prisma.leadPurchase.count({
      where: {
        status: {
          in: ["CONTACTED", "APPOINTMENT_SET", "OFFER_SENT", "WON"],
        },
      },
    }),

    prisma.leadPurchase.count({
      where: {
        status: {
          in: ["OFFER_SENT", "WON"],
        },
      },
    }),

    prisma.lead.groupBy({
      by: ["region"],
      where: {
        createdAt: {
          gte: last30Days,
        },
      },
      _count: {
        _all: true,
      },
      orderBy: {
        _count: {
          region: "desc",
        },
      },
      take: 5,
    }),

    prisma.lead.groupBy({
      by: ["category"],
      where: {
        createdAt: {
          gte: last30Days,
        },
      },
      _count: {
        _all: true,
      },
      orderBy: {
        _count: {
          category: "desc",
        },
      },
      take: 5,
    }),

    prisma.leadPurchase.groupBy({
      by: ["providerId"],
      _count: {
        _all: true,
      },
      _sum: {
        price: true,
      },
      orderBy: {
        _count: {
          providerId: "desc",
        },
      },
      take: 5,
    }),

    prisma.creditPurchase.findMany({
      where: {
        status: "paid",
        createdAt: {
          gte: last7Days,
        },
      },
      select: {
        amount: true,
        createdAt: true,
      },
      orderBy: {
        createdAt: "asc",
      },
    }),

    prisma.fixedOrder.findMany({
      orderBy: {
        createdAt: "desc",
      },
      take: 6,
      select: {
        id: true,
        title: true,
        category: true,
        postalCode: true,
        city: true,
        status: true,
        orderValueCents: true,
        commissionAmountCents: true,
        createdAt: true,
        soldAt: true,
      },
    }),

    prisma.fixedOrder.count(),
    prisma.fixedOrder.count({
      where: {
        status: "OPEN",
      },
    }),
    prisma.fixedOrder.count({
      where: {
        status: "RESERVED",
      },
    }),
    prisma.fixedOrder.count({
      where: {
        status: "SOLD",
      },
    }),
    prisma.fixedOrder.count({
      where: {
        status: "COMPLETED",
      },
    }),

    prisma.fixedOrder.aggregate({
      where: {
        status: {
          in: ["SOLD", "COMPLETED"],
        },
      },
      _sum: {
        commissionAmountCents: true,
      },
    }),

    prisma.fixedOrder.aggregate({
      where: {
        status: {
          in: ["SOLD", "COMPLETED"],
        },
        soldAt: {
          gte: today,
        },
      },
      _sum: {
        commissionAmountCents: true,
      },
    }),

    prisma.fixedOrder.aggregate({
      where: {
        status: {
          in: ["SOLD", "COMPLETED"],
        },
        soldAt: {
          gte: monthStart,
        },
      },
      _sum: {
        commissionAmountCents: true,
      },
    }),
  ]);

  const topProviderIds = topProviders.map((item) => item.providerId);

  const topProviderDetails =
    topProviderIds.length > 0
      ? await prisma.provider.findMany({
          where: {
            id: {
              in: topProviderIds,
            },
          },
          select: {
            id: true,
            companyName: true,
            region: true,
          },
        })
      : [];

  const providerMap = new Map(
    topProviderDetails.map((provider) => [provider.id, provider])
  );

  const totalRevenue = paidCreditAggregate._sum.amount ?? 0;
  const revenueToday = revenueTodayAggregate._sum.amount ?? 0;
  const revenueMonth = revenueMonthAggregate._sum.amount ?? 0;
  const revenueLast7 = revenueLast7Aggregate._sum.amount ?? 0;
  const revenuePrevious7 = revenuePrevious7Aggregate._sum.amount ?? 0;
  const revenueGrowth = growth(revenueLast7, revenuePrevious7);

  const fixedOrderRevenue =
    fixedOrderRevenueAggregate._sum.commissionAmountCents ?? 0;
  const fixedOrderRevenueToday =
    fixedOrderRevenueTodayAggregate._sum.commissionAmountCents ?? 0;
  const fixedOrderRevenueMonth =
    fixedOrderRevenueMonthAggregate._sum.commissionAmountCents ?? 0;

  const totalCreditsSold = paidCreditAggregate._sum.credits ?? 0;
  const totalPayments = paidCreditAggregate._count.id;
  const totalLeadCreditsSpent = leadCreditsAggregate._sum.price ?? 0;

  const approvalRate = percentage(approvedProviderCount, providerCount);
  const purchaseRate = percentage(leadPurchaseCount, leadCount);
  const contactedRate = percentage(contactedCount, leadPurchaseCount);
  const offerRate = percentage(offerSentCount, leadPurchaseCount);
  const wonRate = percentage(wonCount, leadPurchaseCount);

  const maxRegionCount = Math.max(
    ...topRegions.map((item) => item._count._all),
    1
  );

  const maxCategoryCount = Math.max(
    ...topCategories.map((item) => item._count._all),
    1
  );

  const revenueByDay = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(now);
    date.setDate(now.getDate() - (6 - index));
    date.setHours(0, 0, 0, 0);

    const nextDate = new Date(date);
    nextDate.setDate(date.getDate() + 1);

    const amount = revenueChartPurchases
      .filter(
        (purchase) =>
          purchase.createdAt >= date && purchase.createdAt < nextDate
      )
      .reduce((sum, purchase) => sum + purchase.amount, 0);

    return {
      label: new Intl.DateTimeFormat("de-CH", { weekday: "short" }).format(date),
      amount,
    };
  });

  const maxRevenueDay = Math.max(...revenueByDay.map((item) => item.amount), 1);
  const leadGrowth = growth(leadsLast7, leadsPrevious7);
  const providerGrowth = growth(providersLast7, providersPrevious7);
  const purchaseGrowth = growth(leadPurchasesLast7, leadPurchasesPrevious7);

  const monthlyRunRate = revenueMonth;
  const annualRunRate = revenueMonth * 12;
  const activeProviderRate = percentage(
    approvedProviderCount,
    Math.max(providerCount, 1)
  );
  const fixedOrderSellThrough = percentage(
    soldFixedOrderCount + completedFixedOrderCount,
    Math.max(fixedOrderCount, 1)
  );
  const averageRevenuePerPayment =
    totalPayments > 0
      ? Math.round(totalRevenue / totalPayments)
      : 0;

  const aiRecommendation =
    pendingProviderCount > 0
      ? {
          label: "Anbieter prüfen",
          title: `${pendingProviderCount} Anbieter warten auf Freigabe.`,
          text: "Eine schnelle Prüfung erhöht die Zahl aktiver Anbieter und verbessert die regionale Abdeckung.",
          href: "/admin/providers",
          cta: "Anbieter prüfen",
        }
      : purchaseRate < 25
      ? {
          label: "Conversion erhöhen",
          title: "Die Lead-Kaufquote bietet Optimierungspotenzial.",
          text: "Prüfe Leadqualität, Preise und regionale Relevanz. Kleine Anpassungen können die Kaufquote deutlich verbessern.",
          href: "/admin/analytics",
          cta: "Conversion analysieren",
        }
      : {
          label: "Wachstum nutzen",
          title: "Die Plattform entwickelt sich stabil.",
          text: "Nutze die aktuelle Dynamik, um weitere Anbieter zu aktivieren und starke Kategorien gezielt auszubauen.",
          href: "/admin/analytics",
          cta: "Wachstum prüfen",
        };

  const insights = [
    {
      tone: revenueGrowth >= 0 ? "positive" : "warning",
      title: revenueGrowth >= 0 ? "Umsatz entwickelt sich positiv" : "Umsatz beobachten",
      text: `Die letzten 7 Tage liegen ${Math.abs(revenueGrowth)}% ${
        revenueGrowth >= 0 ? "über" : "unter"
      } der Vorperiode.`,
    },
    {
      tone: purchaseRate >= 25 ? "positive" : "info",
      title: "Lead-Conversion",
      text: `${purchaseRate}% aller Leads wurden mindestens einmal gekauft.`,
    },
    {
      tone: pendingProviderCount > 0 ? "warning" : "positive",
      title: pendingProviderCount > 0 ? "Anbieter warten auf Freigabe" : "Anbieterprüfung aktuell",
      text:
        pendingProviderCount > 0
          ? `${pendingProviderCount} Anbieter sollten geprüft werden.`
          : "Momentan sind keine Anbieterfreigaben offen.",
    },
  ];

  const activityFeed = [
    ...latestProviders.map((provider) => ({
      id: `provider-${provider.id}`,
      type: "provider",
      date: provider.createdAt,
      title: "Neue Anbieterregistrierung",
      text: `${provider.companyName} · ${provider.region || "Keine Region"}`,
      href: "/admin/providers",
    })),
    ...latestLeads.map((lead) => ({
      id: `lead-${lead.id}`,
      type: "lead",
      date: lead.createdAt,
      title: "Neuer Lead",
      text: `${lead.title} · ${lead.region}`,
      href: "/admin/leads",
    })),
    ...latestLeadPurchases.map((purchase) => ({
      id: `purchase-${purchase.id}`,
      type: "purchase",
      date: purchase.createdAt,
      title: "Lead gekauft",
      text: `${purchase.provider.companyName} · ${purchase.lead.title}`,
      href: `/leads/${purchase.lead.id}`,
    })),
    ...latestCreditPurchases.map((purchase) => ({
      id: `payment-${purchase.id}`,
      type: "payment",
      date: purchase.createdAt,
      title: "Credit-Zahlung eingegangen",
      text: `${purchase.provider.companyName} · ${formatMoney(
        purchase.amount,
        purchase.currency
      )}`,
      href: "/admin/providers",
    })),
    ...latestFixedOrders.map((order) => ({
      id: `fixed-order-${order.id}`,
      type: order.status === "SOLD" || order.status === "COMPLETED"
        ? "payment"
        : "lead",
      date: order.soldAt || order.createdAt,
      title:
        order.status === "SOLD" || order.status === "COMPLETED"
          ? "Fixauftrag verkauft"
          : "Neuer Fixauftrag",
      text: `${order.title} · ${order.postalCode} ${order.city} · ${formatMoney(
        order.commissionAmountCents
      )}`,
      href: `/admin/fixed-orders/${order.id}`,
    })),
  ]
    .sort((a, b) => b.date.getTime() - a.date.getTime())
    .slice(0, 10);

  const kpis = [
    {
      label: "Umsatz heute",
      value: formatMoney(revenueToday),
      detail: `${revenueGrowth >= 0 ? "+" : ""}${revenueGrowth}% letzte 7 Tage`,
      icon: "CHF",
      tone: "emerald",
    },
    {
      label: "Umsatz diesen Monat",
      value: formatMoney(revenueMonth),
      detail: `${formatMoney(totalRevenue)} Gesamtumsatz`,
      icon: "↗",
      tone: "blue",
    },
    {
      label: "Anbieter",
      value: formatNumber(providerCount),
      detail: `+${providersToday} heute · ${pendingProviderCount} offen`,
      icon: "P",
      tone: "violet",
    },
    {
      label: "Lead-Verkäufe",
      value: formatNumber(leadPurchaseCount),
      detail: `+${leadPurchasesToday} heute`,
      icon: "K",
      tone: "amber",
    },
    {
      label: "Fixaufträge",
      value: formatNumber(fixedOrderCount),
      detail: `${openFixedOrderCount} offen · ${soldFixedOrderCount + completedFixedOrderCount} verkauft`,
      icon: "F",
      tone: "emerald",
    },
  ];

  return (
    <main className="admin-page">
      <div className="admin-backdrop" />

      <div className="admin-shell">
        <header className="admin-hero">
          <div>
            <div className="admin-kicker">
              <span className="admin-live-dot" />
              Auftrago Administration
            </div>

            <h1>Willkommen zurück, Dejan.</h1>

            <p>
              Umsatz, Anbieter, Leads und Verkäufe in einer zentralen
              Unternehmensansicht.
            </p>
          </div>

          <div className="admin-actions">
            <Link href="/admin/leads" className="admin-btn admin-btn-primary">
              + Neuer Lead
            </Link>

            <Link
              href="/admin/fixed-orders/new"
              className="admin-btn admin-btn-primary"
            >
              + Neuer Fixauftrag
            </Link>

            <Link
              href="/admin/providers"
              className="admin-btn admin-btn-secondary"
            >
              Anbieter verwalten
            </Link>

            <Link href="/admin/analytics" className="admin-btn admin-btn-secondary">
              Analytics
            </Link>

            <Link href="/admin/seo" className="admin-btn admin-btn-secondary">
              SEO Center
            </Link>

            <Link href="/admin/activity" className="admin-btn admin-btn-secondary">
              Activities
            </Link>

            <Link href="/admin/system" className="admin-btn admin-btn-secondary">
              System
            </Link>

            <Link
              href="/admin/notifications"
              className="admin-btn admin-btn-secondary"
            >
              Notifications
            </Link>

            <Link href="/admin/ai" className="admin-btn admin-btn-secondary">
              AI Center
            </Link>

            <Link href="/admin/audit" className="admin-btn admin-btn-secondary">
              Audit Log
            </Link>

            <Link
              href="/admin/settings"
              className="admin-btn admin-btn-secondary"
            >
              Einstellungen
            </Link>

            <AdminAutoRefresh intervalSeconds={15} />

            <Link href="/admin-logout" className="admin-btn admin-btn-ghost">
              Abmelden
            </Link>
          </div>
        </header>

        {pendingProviderCount > 0 ? (
          <Link href="/admin/providers" className="admin-alert">
            <div>
              <span>Handlungsbedarf</span>
              <strong>
                {pendingProviderCount}{" "}
                {pendingProviderCount === 1
                  ? "Anbieter wartet"
                  : "Anbieter warten"}{" "}
                auf Freigabe
              </strong>
            </div>

            <b>Jetzt prüfen →</b>
          </Link>
        ) : null}

        <section
          style={{
            marginBottom: 24,
            overflow: "hidden",
            border: "1px solid rgba(56,189,248,0.18)",
            borderRadius: 28,
            background:
              "radial-gradient(circle at 90% 0%, rgba(56,189,248,0.14), transparent 34%), linear-gradient(145deg, rgba(15,23,42,0.98), rgba(7,11,20,0.98))",
            padding: 26,
          }}
          aria-label="Abonnements und Lead-Zugriff"
        >
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "space-between",
              gap: 20,
              flexWrap: "wrap",
            }}
          >
            <div>
              <span
                style={{
                  color: "#7dd3fc",
                  fontSize: 11,
                  fontWeight: 900,
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                }}
              >
                Anbieter-Mitgliedschaften
              </span>

              <h2
                style={{
                  marginTop: 9,
                  marginBottom: 7,
                  color: "#ffffff",
                  fontSize: 27,
                }}
              >
                Abonnements & Lead-Zugriff
              </h2>

              <p
                style={{
                  margin: 0,
                  color: "#94a3b8",
                  lineHeight: 1.65,
                }}
              >
                Aktive Stripe-Abos, Testphasen, manuelle Freigaben und
                gesperrte Anbieter zentral überwachen.
              </p>
            </div>

            <Link
              href="/admin/providers"
              className="admin-btn admin-btn-primary"
            >
              Anbieter-Abos verwalten
            </Link>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(auto-fit, minmax(170px, 1fr))",
              gap: 12,
              marginTop: 22,
            }}
          >
            {[
              {
                label: "Aktive Abos",
                value: activeSubscriptionCount,
                detail: "Stripe ACTIVE",
                color: "#86efac",
                href: "/admin/providers?subscription=ACTIVE",
              },
              {
                label: "Testphase",
                value: trialSubscriptionCount,
                detail: "Stripe TRIALING",
                color: "#fde68a",
                href: "/admin/providers?subscription=TRIALING",
              },
              {
                label: "Manuell frei",
                value: manualSubscriptionCount,
                detail: "Admin-Ausnahme",
                color: "#c4b5fd",
                href: "/admin/providers?subscription=MANUAL",
              },
              {
                label: "Zahlung offen",
                value: paymentProblemSubscriptionCount,
                detail: "Past due / unpaid",
                color: "#fdba74",
                href: "/admin/providers?subscription=PAYMENT_PROBLEM",
              },
              {
                label: "Gekündigt",
                value: cancelledSubscriptionCount,
                detail: "Beendet oder vorgemerkt",
                color: "#fda4af",
                href: "/admin/providers?subscription=CANCELLED",
              },
              {
                label: "Kein Lead-Zugriff",
                value: noLeadAccessCount,
                detail: "Genehmigt, aber ohne Abo",
                color: "#fca5a5",
                href: "/admin/providers?subscription=NO_ACCESS",
              },
            ].map((item) => (
              <Link
                key={item.label}
                href={item.href}
                style={{
                  display: "block",
                  padding: 17,
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: 17,
                  background: "rgba(255,255,255,0.035)",
                  textDecoration: "none",
                }}
              >
                <span
                  style={{
                    display: "block",
                    color: "#94a3b8",
                    fontSize: 10,
                    fontWeight: 900,
                    letterSpacing: "0.08em",
                    textTransform: "uppercase",
                  }}
                >
                  {item.label}
                </span>

                <strong
                  style={{
                    display: "block",
                    marginTop: 10,
                    color: item.color,
                    fontSize: 30,
                    lineHeight: 1,
                  }}
                >
                  {item.value}
                </strong>

                <small
                  style={{
                    display: "block",
                    marginTop: 8,
                    color: "#64748b",
                  }}
                >
                  {item.detail}
                </small>
              </Link>
            ))}
          </div>
        </section>

        <section
          style={{
            marginBottom: 24,
            display: "grid",
            gridTemplateColumns:
              "repeat(auto-fit, minmax(210px, 1fr))",
            gap: 14,
          }}
          aria-label="Executive Kennzahlen"
        >
          {[
            {
              label: "MRR",
              value: formatMoney(monthlyRunRate),
              detail: "Monatsumsatz aktuell",
              tone: "#6ee7b7",
            },
            {
              label: "ARR",
              value: formatMoney(annualRunRate),
              detail: "Hochrechnung auf 12 Monate",
              tone: "#7dd3fc",
            },
            {
              label: "Aktive Anbieter",
              value: `${activeProviderRate}%`,
              detail: `${approvedProviderCount} genehmigt`,
              tone: "#c4b5fd",
            },
            {
              label: "Fixauftrag-Sell-through",
              value: `${fixedOrderSellThrough}%`,
              detail: "Verkauft oder abgeschlossen",
              tone: "#fcd34d",
            },
            {
              label: "Ø Zahlung",
              value: formatMoney(averageRevenuePerPayment),
              detail: "Pro bezahltem Credit-Paket",
              tone: "#f9a8d4",
            },
          ].map((item) => (
            <article
              key={item.label}
              style={{
                border: "1px solid rgba(255,255,255,0.09)",
                borderRadius: 22,
                background:
                  "linear-gradient(145deg, rgba(255,255,255,0.045), rgba(7,11,20,0.96))",
                padding: 22,
              }}
            >
              <span
                style={{
                  color: item.tone,
                  fontSize: 11,
                  fontWeight: 900,
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                }}
              >
                {item.label}
              </span>
              <strong
                style={{
                  display: "block",
                  marginTop: 13,
                  color: "#ffffff",
                  fontSize: 29,
                  lineHeight: 1.05,
                }}
              >
                {item.value}
              </strong>
              <small
                style={{
                  display: "block",
                  marginTop: 9,
                  color: "#94a3b8",
                  lineHeight: 1.55,
                }}
              >
                {item.detail}
              </small>
            </article>
          ))}
        </section>

        <section
          style={{
            marginBottom: 24,
            overflow: "hidden",
            position: "relative",
            border: "1px solid rgba(56,189,248,0.18)",
            borderRadius: 28,
            background:
              "radial-gradient(circle at 86% 20%, rgba(56,189,248,0.18), transparent 30%), linear-gradient(135deg, rgba(8,47,73,0.48), rgba(7,11,20,0.97))",
            padding: 28,
          }}
        >
          <div
            style={{
              position: "relative",
              zIndex: 1,
              display: "flex",
              flexWrap: "wrap",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 24,
            }}
          >
            <div style={{ maxWidth: 780 }}>
              <span
                style={{
                  display: "inline-flex",
                  padding: "7px 11px",
                  borderRadius: 999,
                  background: "rgba(56,189,248,0.1)",
                  color: "#7dd3fc",
                  fontSize: 11,
                  fontWeight: 900,
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                }}
              >
                ✦ Business AI · {aiRecommendation.label}
              </span>

              <h2
                style={{
                  marginTop: 14,
                  color: "#ffffff",
                  fontSize: "clamp(24px, 3vw, 34px)",
                  lineHeight: 1.18,
                }}
              >
                {aiRecommendation.title}
              </h2>

              <p
                style={{
                  marginTop: 10,
                  color: "#a8b3c7",
                  fontSize: 14,
                  lineHeight: 1.75,
                }}
              >
                {aiRecommendation.text}
              </p>
            </div>

            <Link
              href={aiRecommendation.href}
              className="admin-btn admin-btn-primary"
            >
              {aiRecommendation.cta}
            </Link>
          </div>
        </section>

        <section className="admin-kpi-grid">
          {kpis.map((item) => (
            <article
              className={`admin-kpi admin-kpi-${item.tone}`}
              key={item.label}
            >
              <div className="admin-kpi-head">
                <span>{item.label}</span>
                <b>{item.icon}</b>
              </div>

              <strong>{item.value}</strong>
              <small>{item.detail}</small>
            </article>
          ))}
        </section>

        <section className="admin-command-grid">
          <article className="admin-panel admin-revenue-panel">
            <div className="admin-panel-head">
              <div>
                <span>Umsatzverlauf</span>
                <h2>Letzte 7 Tage</h2>
              </div>
              <Link href="/admin/analytics">Details →</Link>
            </div>

            <div className="admin-chart">
              {revenueByDay.map((item) => (
                <div className="admin-chart-column" key={item.label}>
                  <div className="admin-chart-value">
                    {item.amount > 0 ? formatMoney(item.amount) : "–"}
                  </div>
                  <div className="admin-chart-track">
                    <i
                      style={{
                        height: `${Math.max((item.amount / maxRevenueDay) * 100, 5)}%`,
                      }}
                    />
                  </div>
                  <span>{item.label}</span>
                </div>
              ))}
            </div>

            <div className="admin-trend-strip">
              <div>
                <span>Leads</span>
                <strong className={leadGrowth >= 0 ? "trend-up" : "trend-down"}>
                  {leadGrowth >= 0 ? "+" : ""}{leadGrowth}%
                </strong>
              </div>
              <div>
                <span>Anbieter</span>
                <strong className={providerGrowth >= 0 ? "trend-up" : "trend-down"}>
                  {providerGrowth >= 0 ? "+" : ""}{providerGrowth}%
                </strong>
              </div>
              <div>
                <span>Lead-Käufe</span>
                <strong className={purchaseGrowth >= 0 ? "trend-up" : "trend-down"}>
                  {purchaseGrowth >= 0 ? "+" : ""}{purchaseGrowth}%
                </strong>
              </div>
            </div>
          </article>

          <article className="admin-panel admin-insights-panel">
            <div className="admin-panel-head">
              <div>
                <span>Business Intelligence</span>
                <h2>Automatische Hinweise</h2>
              </div>
            </div>

            <div className="admin-insight-list">
              {insights.map((item) => (
                <div className={`admin-insight insight-${item.tone}`} key={item.title}>
                  <b />
                  <div>
                    <strong>{item.title}</strong>
                    <span>{item.text}</span>
                  </div>
                </div>
              ))}
            </div>
          </article>
        </section>

        <section className="admin-main-grid">
          <article className="admin-panel admin-live-panel">
            <div className="admin-panel-head">
              <div>
                <span>Live Feed</span>
                <h2>Was gerade passiert</h2>
              </div>

              <small>Automatisch aktualisiert</small>
            </div>

            <div className="admin-activity-list">
              {activityFeed.length === 0 ? (
                <p className="admin-empty">Noch keine Aktivitäten vorhanden.</p>
              ) : (
                activityFeed.map((item) => (
                  <Link
                    href={item.href}
                    key={item.id}
                    className="admin-activity-row"
                  >
                    <div
                      className={`admin-activity-icon activity-${item.type}`}
                    >
                      {activityIcon(item.type)}
                    </div>

                    <div className="admin-activity-copy">
                      <strong>{item.title}</strong>
                      <span>{item.text}</span>
                    </div>

                    <time>{formatDate(item.date)}</time>
                  </Link>
                ))
              )}
            </div>
          </article>

          <article className="admin-panel admin-funnel-panel">
            <div className="admin-panel-head">
              <div>
                <span>Conversion</span>
                <h2>Verkaufs-Funnel</h2>
              </div>
            </div>

            <div className="admin-funnel">
              {[
                {
                  label: "Leads",
                  value: leadCount,
                  percent: 100,
                },
                {
                  label: "Gekauft",
                  value: leadPurchaseCount,
                  percent: purchaseRate,
                },
                {
                  label: "Kontaktiert",
                  value: contactedCount,
                  percent: contactedRate,
                },
                {
                  label: "Offerte",
                  value: offerSentCount,
                  percent: offerRate,
                },
                {
                  label: "Gewonnen",
                  value: wonCount,
                  percent: wonRate,
                },
              ].map((item) => (
                <div className="admin-funnel-row" key={item.label}>
                  <div className="admin-funnel-title">
                    <span>{item.label}</span>
                    <strong>{formatNumber(item.value)}</strong>
                  </div>

                  <div className="admin-funnel-track">
                    <i style={{ width: `${Math.max(item.percent, 3)}%` }} />
                  </div>

                  <small>{item.percent}%</small>
                </div>
              ))}
            </div>

            <div className="admin-mini-stats">
              <div>
                <span>Genehmigt</span>
                <strong>{approvedProviderCount}</strong>
              </div>

              <div>
                <span>Ausstehend</span>
                <strong>{pendingProviderCount}</strong>
              </div>

              <div>
                <span>Freigabequote</span>
                <strong>{approvalRate}%</strong>
              </div>
            </div>
          </article>
        </section>

        <section className="admin-panel" style={{ marginBottom: 24 }}>
          <div className="admin-panel-head">
            <div>
              <span>Fixaufträge</span>
              <h2>Bestätigte Aufträge im Überblick</h2>
            </div>

            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <Link href="/admin/fixed-orders/analytics">Analytics →</Link>
              <Link href="/admin/fixed-orders">Alle anzeigen →</Link>
            </div>
          </div>

          <div className="admin-mini-stats">
            <div>
              <span>Offen</span>
              <strong>{openFixedOrderCount}</strong>
            </div>

            <div>
              <span>Reserviert</span>
              <strong>{reservedFixedOrderCount}</strong>
            </div>

            <div>
              <span>Verkauft</span>
              <strong>{soldFixedOrderCount}</strong>
            </div>

            <div>
              <span>Erledigt</span>
              <strong>{completedFixedOrderCount}</strong>
            </div>

            <div>
              <span>Provision heute</span>
              <strong>{formatMoney(fixedOrderRevenueToday)}</strong>
            </div>

            <div>
              <span>Provision Monat</span>
              <strong>{formatMoney(fixedOrderRevenueMonth)}</strong>
            </div>
          </div>

          <div className="admin-compact-list" style={{ marginTop: 20 }}>
            {latestFixedOrders.length === 0 ? (
              <p className="admin-empty">Noch keine Fixaufträge vorhanden.</p>
            ) : (
              latestFixedOrders.map((order) => (
                <Link
                  href={`/admin/fixed-orders/${order.id}`}
                  className="admin-compact-row"
                  key={order.id}
                >
                  <div className="admin-lead-price">
                    {order.status === "OPEN"
                      ? "OFFEN"
                      : order.status === "RESERVED"
                        ? "RES."
                        : order.status === "SOLD"
                          ? "SOLD"
                          : order.status === "COMPLETED"
                            ? "DONE"
                            : "STOP"}
                  </div>

                  <div className="admin-compact-main">
                    <strong>{order.title}</strong>
                    <span>
                      {order.category} · {order.postalCode} {order.city}
                    </span>
                  </div>

                  <div className="admin-sales-count">
                    <strong>{formatMoney(order.commissionAmountCents)}</strong>
                    <span>{formatMoney(order.orderValueCents)} Auftrag</span>
                  </div>
                </Link>
              ))
            )}
          </div>
        </section>

        <section className="admin-metric-grid">
          <article className="admin-panel admin-number-panel">
            <span>Credits verkauft</span>
            <strong>{formatNumber(totalCreditsSold)}</strong>
            <small>{formatNumber(totalPayments)} bezahlte Pakete</small>
          </article>

          <article className="admin-panel admin-number-panel">
            <span>Credits eingesetzt</span>
            <strong>{formatNumber(totalLeadCreditsSpent)}</strong>
            <small>Für freigeschaltete Leads</small>
          </article>

          <article className="admin-panel admin-number-panel">
            <span>Neue Leads heute</span>
            <strong>{formatNumber(leadsToday)}</strong>
            <small>{formatNumber(leadCount)} Leads insgesamt</small>
          </article>

          <article className="admin-panel admin-number-panel">
            <span>Neue Anbieter heute</span>
            <strong>{formatNumber(providersToday)}</strong>
            <small>{formatNumber(blockedProviderCount)} gesperrt</small>
          </article>

          <article className="admin-panel admin-number-panel">
            <span>Fixauftrag-Provision</span>
            <strong>{formatMoney(fixedOrderRevenue)}</strong>
            <small>{formatNumber(soldFixedOrderCount + completedFixedOrderCount)} Verkäufe</small>
          </article>
        </section>

        <section className="admin-ranking-grid">
          <article className="admin-panel">
            <div className="admin-panel-head">
              <div>
                <span>Letzte 30 Tage</span>
                <h2>Top-Regionen</h2>
              </div>
            </div>

            <div className="admin-ranking-list">
              {topRegions.length === 0 ? (
                <p className="admin-empty">Noch keine Daten.</p>
              ) : (
                topRegions.map((item, index) => (
                  <div className="admin-ranking-row" key={item.region}>
                    <div className="admin-ranking-label">
                      <b>{index + 1}</b>
                      <span>{item.region || "Ohne Region"}</span>
                    </div>

                    <div className="admin-ranking-bar">
                      <i
                        style={{
                          width: `${Math.round(
                            (item._count._all / maxRegionCount) * 100
                          )}%`,
                        }}
                      />
                    </div>

                    <strong>{item._count._all}</strong>
                  </div>
                ))
              )}
            </div>
          </article>

          <article className="admin-panel">
            <div className="admin-panel-head">
              <div>
                <span>Letzte 30 Tage</span>
                <h2>Top-Kategorien</h2>
              </div>
            </div>

            <div className="admin-ranking-list">
              {topCategories.length === 0 ? (
                <p className="admin-empty">Noch keine Daten.</p>
              ) : (
                topCategories.map((item, index) => (
                  <div className="admin-ranking-row" key={item.category}>
                    <div className="admin-ranking-label">
                      <b>{index + 1}</b>
                      <span>{item.category || "Ohne Kategorie"}</span>
                    </div>

                    <div className="admin-ranking-bar">
                      <i
                        style={{
                          width: `${Math.round(
                            (item._count._all / maxCategoryCount) * 100
                          )}%`,
                        }}
                      />
                    </div>

                    <strong>{item._count._all}</strong>
                  </div>
                ))
              )}
            </div>
          </article>

          <article className="admin-panel">
            <div className="admin-panel-head">
              <div>
                <span>Nach Käufen</span>
                <h2>Top-Anbieter</h2>
              </div>
            </div>

            <div className="admin-provider-ranking">
              {topProviders.length === 0 ? (
                <p className="admin-empty">Noch keine Käufe.</p>
              ) : (
                topProviders.map((item, index) => {
                  const provider = providerMap.get(item.providerId);
                  const name =
                    provider?.companyName || "Unbekannter Anbieter";

                  return (
                    <div
                      className="admin-provider-rank-row"
                      key={item.providerId}
                    >
                      <div className="admin-rank-position">{index + 1}</div>
                      <div className="admin-avatar">{initials(name)}</div>

                      <div className="admin-provider-copy">
                        <strong>{name}</strong>
                        <span>{provider?.region || "Keine Region"}</span>
                      </div>

                      <div className="admin-rank-value">
                        <strong>{item._count._all}</strong>
                        <span>Käufe</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </article>
        </section>

        <section className="admin-double-grid">
          <article className="admin-panel">
            <div className="admin-panel-head">
              <div>
                <span>Neueste</span>
                <h2>Anbieter</h2>
              </div>

              <Link href="/admin/providers">Alle anzeigen →</Link>
            </div>

            <div className="admin-compact-list">
              {latestProviders.map((provider) => {
                const status = providerStatus(provider.status);

                return (
                  <div className="admin-compact-row" key={provider.id}>
                    <div className="admin-avatar">
                      {initials(provider.companyName)}
                    </div>

                    <div className="admin-compact-main">
                      <strong>{provider.companyName}</strong>
                      <span>
                        {provider.contactName} ·{" "}
                        {provider.region || "Keine Region"}
                      </span>
                    </div>

                    <span
                      className={`admin-status ${status.className}`}
                    >
                      {status.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </article>

          <article className="admin-panel">
            <div className="admin-panel-head">
              <div>
                <span>Neueste</span>
                <h2>Leads</h2>
              </div>

              <Link href="/admin/leads">Alle anzeigen →</Link>
            </div>

            <div className="admin-compact-list">
              {latestLeads.map((lead) => (
                <div className="admin-compact-row" key={lead.id}>
                  <div className="admin-lead-price">{lead.price}</div>

                  <div className="admin-compact-main">
                    <strong>{lead.title}</strong>
                    <span>
                      {lead.region} · {lead.category}
                    </span>
                  </div>

                  <div className="admin-sales-count">
                    <strong>{lead._count.purchases}</strong>
                    <span>Verkäufe</span>
                  </div>
                </div>
              ))}
            </div>
          </article>
        </section>

        <section className="admin-system-grid">
          {[
            { label: "Plattform", text: "Admin-Dashboard erreichbar", status: "Online" },
            { label: "Datenbank", text: "Prisma-Abfragen erfolgreich", status: "Verbunden" },
            { label: "Zahlungen", text: `${formatNumber(totalPayments)} bezahlte Pakete`, status: "Aktiv" },
            { label: "CRM", text: `${formatNumber(contactedCount)} Kontakte bearbeitet`, status: "Aktiv" },
          ].map((item) => (
            <article className="admin-system-card" key={item.label}>
              <div className="admin-system-status"><i />{item.status}</div>
              <strong>{item.label}</strong>
              <span>{item.text}</span>
            </article>
          ))}
        </section>

        <section className="admin-quick-actions">
          <Link href="/admin/fixed-orders/new">
            <span>🔥</span>
            <strong>Fixauftrag erstellen</strong>
            <small>Bestätigten Auftrag veröffentlichen</small>
          </Link>

          <Link href="/admin/leads">
            <span>＋</span>
            <strong>Neuen Lead erstellen</strong>
            <small>Kundenanfrage erfassen</small>
          </Link>

          <Link href="/admin/providers">
            <span>✓</span>
            <strong>Anbieter freigeben</strong>
            <small>Profile prüfen und verwalten</small>
          </Link>

          <Link href="/admin/activity">
            <span>↗</span>
            <strong>Aktivitäten prüfen</strong>
            <small>Logins und Nutzung analysieren</small>
          </Link>

          <Link href="/admin/analytics">
            <span>◎</span>
            <strong>Analytics öffnen</strong>
            <small>Entwicklung und Conversion prüfen</small>
          </Link>

          <Link href="/admin/ai">
            <span>✦</span>
            <strong>AI Center öffnen</strong>
            <small>Automatische Analysen und Empfehlungen</small>
          </Link>

          <Link href="/admin/audit">
            <span>◫</span>
            <strong>Audit Log prüfen</strong>
            <small>Administrative Änderungen nachvollziehen</small>
          </Link>

          <Link href="/admin/settings">
            <span>⚙</span>
            <strong>Einstellungen</strong>
            <small>Plattform und Benachrichtigungen verwalten</small>
          </Link>
        </section>
      </div>
    </main>
  );
}