import { getServerLocale } from "@/lib/i18n/server";
import type { Locale } from "@/lib/i18n/config";
import Link from "next/link";

import { translateHomeText } from "@/lib/i18n/home-translator";

const showcaseLeads = [
  {
    icon: "🧹",
    title: "Umzugsreinigung 3.5 Zimmer",
    region: "Aargau",
    category: "Reinigung",
    timing: "Termin flexibel",
    credits: 20,
    status: "Neu",
    statusClass:
      "border-orange-300/25 bg-orange-400/10 text-orange-200",
    glow:
      "from-sky-400/20 via-cyan-400/5 to-transparent",
  },
  {
    icon: "🎨",
    title: "Malerarbeiten Wohnung",
    region: "Zürich",
    category: "Maler",
    timing: "Innerhalb 2 Wochen",
    credits: 25,
    status: "Aktiv",
    statusClass:
      "border-emerald-300/25 bg-emerald-400/10 text-emerald-200",
    glow:
      "from-orange-400/20 via-amber-400/5 to-transparent",
  },
  {
    icon: "🚚",
    title: "Privatumzug mit Möbelmontage",
    region: "Luzern",
    category: "Umzug",
    timing: "Fixer Termin",
    credits: 35,
    status: "Top Auftrag",
    statusClass:
      "border-violet-300/25 bg-violet-400/10 text-violet-200",
    glow:
      "from-violet-400/20 via-indigo-400/5 to-transparent",
  },
  {
    icon: "🌿",
    title: "Gartenpflege & Heckenschnitt",
    region: "Bern",
    category: "Gartenpflege",
    timing: "Nächste Woche",
    credits: 20,
    status: "Aktiv",
    statusClass:
      "border-emerald-300/25 bg-emerald-400/10 text-emerald-200",
    glow:
      "from-emerald-400/20 via-teal-400/5 to-transparent",
  },
  {
    icon: "⚡",
    title: "Elektriker für Beleuchtung",
    region: "Basel",
    category: "Elektriker",
    timing: "Schnellstmöglich",
    credits: 25,
    status: "Dringend",
    statusClass:
      "border-red-300/25 bg-red-400/10 text-red-200",
    glow:
      "from-yellow-400/20 via-orange-400/5 to-transparent",
  },
  {
    icon: "🏢",
    title: "Hauswartung für Liegenschaft",
    region: "Zug",
    category: "Hauswartung",
    timing: "Wiederkehrend",
    credits: 40,
    status: "Premium",
    statusClass:
      "border-sky-300/25 bg-sky-400/10 text-sky-200",
    glow:
      "from-cyan-400/20 via-blue-400/5 to-transparent",
  },
];

const providerBenefits = [
  "Aufträge aus deinen Regionen",
  "Nur passende Kategorien",
  "Volle Kostenkontrolle",
  "Keine klassische Kaltakquise",
];

export default async function LiveLeadsSection({ locale }: { locale?: Locale } = {}) {
  const effectiveLocale = locale ?? await getServerLocale();

  const tr = (value: string) => translateHomeText(effectiveLocale, value);

  const leads = showcaseLeads.map((lead) => ({
    ...lead,
    title: tr(lead.title),
    region: tr(lead.region),
    category: tr(lead.category),
    timing: tr(lead.timing),
    status: tr(lead.status),
  }));

  const benefits = providerBenefits.map(tr);

  return (
    <section className="relative overflow-hidden px-5 py-28 sm:px-8 lg:px-12 lg:py-40">
      <style
        dangerouslySetInnerHTML={{
          __html: `
            @keyframes leadsPulse {
              0%, 100% {
                opacity: .5;
                transform: scale(1);
              }
              50% {
                opacity: 1;
                transform: scale(1.15);
              }
            }

            @keyframes leadsFloat {
              0%, 100% {
                transform: translateY(0);
              }
              50% {
                transform: translateY(-8px);
              }
            }

            @keyframes leadsBeam {
              0% {
                transform: translateX(-180%) rotate(14deg);
              }
              100% {
                transform: translateX(420%) rotate(14deg);
              }
            }

            .lead-live-dot {
              animation: leadsPulse 2s ease-in-out infinite;
            }

            .lead-float {
              animation: leadsFloat 7s ease-in-out infinite;
            }

            .lead-card-shine::before {
              content: "";
              position: absolute;
              top: -70%;
              bottom: -70%;
              left: -40%;
              width: 24%;
              background:
                linear-gradient(
                  90deg,
                  transparent,
                  rgba(255,255,255,.09),
                  transparent
                );
              transform: rotate(14deg);
              transition: left .9s ease;
              pointer-events: none;
            }

            .lead-card-shine:hover::before {
              left: 125%;
            }

            @media (prefers-reduced-motion: reduce) {
              .lead-live-dot,
              .lead-float {
                animation: none !important;
              }
            }
          `,
        }}
      />

      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(34,197,94,0.12),transparent_35%),radial-gradient(circle_at_10%_70%,rgba(56,189,248,0.08),transparent_32%),radial-gradient(circle_at_90%_75%,rgba(139,92,246,0.09),transparent_32%),linear-gradient(180deg,#03110f_0%,#020712_100%)]" />

      <div className="absolute left-1/2 top-0 h-px w-[80%] -translate-x-1/2 bg-gradient-to-r from-transparent via-emerald-300/40 to-transparent" />

      <div className="relative mx-auto max-w-[1500px]">
        <div className="grid items-end gap-10 lg:grid-cols-[1fr_470px]">
          <div>
            <div className="inline-flex items-center gap-3 rounded-full border border-emerald-300/25 bg-emerald-400/[0.08] px-4 py-2 text-xs font-black uppercase tracking-[0.22em] text-emerald-200">
              <span className="relative flex h-2.5 w-2.5">
                <span className="lead-live-dot absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-70" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-400" />
              </span>
              {tr("Neue Kundenanfragen")}
            </div>

            <h2 className="mt-7 max-w-[950px] text-[3.4rem] font-black leading-[0.92] tracking-[-0.07em] sm:text-[5rem] lg:text-[6.2rem]">
          {tr("Aufträge, die zu deinem Betrieb passen.")}
        </h2>
          </div>

          <div className="lg:pb-2">
            <p className="text-lg font-medium leading-8 text-slate-400">
              {tr("Scopri richieste attuali provenienti da diverse regioni e settori. I fornitori registrati possono vedere tutti i dettagli della richiesta e i dati di contatto dopo lo sblocco.")}
            </p>

            <div className="mt-6 flex flex-wrap gap-3 text-xs font-black text-slate-300">
              <span className="rounded-full border border-white/[0.08] bg-white/[0.04] px-4 py-2">
                {tr("✓ Richieste regionali")}
              </span>
              <span className="rounded-full border border-white/[0.08] bg-white/[0.04] px-4 py-2">
                {tr("✓ Nuove categorie")}
              </span>
              <span className="rounded-full border border-white/[0.08] bg-white/[0.04] px-4 py-2">
                {tr("✓ Direkter Kontakt mit dem Kunden")}
              </span>
            </div>
          </div>
        </div>

        <div className="mt-16 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {leads.map((lead, index) => (
            <article
              key={`${lead.title}-${lead.region}`}
              className="lead-card-shine group relative min-h-[390px] overflow-hidden rounded-[34px] border border-white/[0.1] bg-[#0a1121]/95 p-6 shadow-[0_28px_90px_rgba(0,0,0,0.35)] transition duration-500 hover:-translate-y-3 hover:border-white/20 hover:shadow-[0_42px_120px_rgba(0,0,0,0.5)] sm:p-7"
            >
              <div
                className={[
                  "absolute inset-0 bg-gradient-to-br opacity-70 transition duration-500 group-hover:opacity-100",
                  lead.glow,
                ].join(" ")}
              />

              <div className="absolute right-5 top-4 text-[11px] font-black tracking-[0.18em] text-white/[0.08]">
                {String(index + 1).padStart(2, "0")}
              </div>

              <div className="relative flex h-full flex-col">
                <div className="flex items-start justify-between gap-5">
                  <span className="flex h-14 w-14 items-center justify-center rounded-[20px] border border-white/10 bg-black/25 text-2xl shadow-[0_16px_45px_rgba(0,0,0,0.24)] transition duration-500 group-hover:rotate-3 group-hover:scale-110">
                    {lead.icon}
                  </span>

                  <span
                    className={[
                      "rounded-full border px-3 py-1.5 text-xs font-black",
                      lead.statusClass,
                    ].join(" ")}
                  >
                    {lead.status}
                  </span>
                </div>

                <p className="mt-8 text-xs font-black uppercase tracking-[0.18em] text-slate-500">
                  {tr("Richiesta attuale del cliente")}
                </p>

                <h3 className="mt-3 max-w-[330px] text-2xl font-black leading-[1.05] tracking-[-0.045em]">
                  {lead.title}
                </h3>

                <div className="mt-6 flex flex-wrap gap-2">
                  <span className="rounded-full border border-white/[0.07] bg-white/[0.05] px-3 py-2 text-xs font-bold text-slate-300">
                    📍 {lead.region}
                  </span>
                  <span className="rounded-full border border-white/[0.07] bg-white/[0.05] px-3 py-2 text-xs font-bold text-slate-300">
                    {tr(lead.category)}
                  </span>
                  <span className="rounded-full border border-white/[0.07] bg-white/[0.05] px-3 py-2 text-xs font-bold text-slate-300">
                    ⏱ {lead.timing}
                  </span>
                </div>

                <div className="mt-6 rounded-[22px] border border-white/[0.07] bg-black/20 p-4">
                  <div className="flex items-start gap-3">
                    <span className="mt-0.5 text-sm">🔒</span>
                    <p className="text-xs font-medium leading-6 text-slate-400">
                      {tr(
                    "Die vollständige Beschreibung, Adresse, Datum und Kontaktdaten sind nach der Freischaltung sichtbar."
                  )}
                    </p>
                  </div>
                </div>

                <div className="mt-auto flex items-end justify-between gap-4 pt-7">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-500">
                      {tr("Sblocco")}
                    </p>

                    <div className="mt-2 flex items-center gap-3">
                      <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-yellow-300 to-orange-500 text-xl shadow-[0_0_35px_rgba(250,204,21,0.32)]">
                        💰
                      </span>

                      <div>
                        <strong className="block text-3xl font-black leading-none tracking-[-0.05em] text-yellow-300">
                          {lead.credits}
                        </strong>
                        <span className="text-[10px] font-black uppercase tracking-[0.15em] text-yellow-200/70">
                          Credits
                        </span>
                      </div>
                    </div>
                  </div>

                  <Link
                    href="/login"
                    className="group/button inline-flex min-h-[48px] items-center justify-center rounded-2xl bg-gradient-to-r from-sky-400 via-blue-500 to-violet-500 px-5 text-sm font-black shadow-[0_16px_45px_rgba(59,130,246,0.25)] transition duration-300 hover:-translate-y-1 hover:shadow-[0_22px_65px_rgba(59,130,246,0.4)]"
                  >
                    {tr("Anfrage ansehen")}
                    <span className="ml-2 transition group-hover/button:translate-x-1">
                      →
                    </span>
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>

        <div className="relative mt-10 overflow-hidden rounded-[42px] border border-white/[0.1] bg-[#09101f] p-7 shadow-[0_35px_120px_rgba(0,0,0,0.42)] sm:p-10 lg:p-12">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_0%_30%,rgba(56,189,248,0.17),transparent_36%),radial-gradient(circle_at_100%_70%,rgba(139,92,246,0.17),transparent_36%)]" />

          <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full border border-dashed border-white/[0.06]" />

          <div className="relative grid gap-12 lg:grid-cols-[1.05fr_.95fr] lg:items-center">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-violet-300/20 bg-violet-400/[0.07] px-4 py-2 text-xs font-black uppercase tracking-[0.2em] text-violet-200">
                🚀 {tr("Für Schweizer Dienstleister")}
              </span>

              <h3 className="mt-6 max-w-[780px] text-4xl font-black leading-[0.98] tracking-[-0.055em] sm:text-5xl lg:text-6xl">
                {tr("Kunden suchen bereits.")}
                <span className="block bg-gradient-to-r from-sky-300 via-indigo-300 to-fuchsia-300 bg-clip-text text-transparent">
                  {tr("Sei dort, wenn es zählt.")}
                </span>
              </h3>

              <p className="mt-6 max-w-[720px] text-base font-medium leading-8 text-slate-400 sm:text-lg">
                Registriere deinen Betrieb, wähle deine Regionen und
                Dienstleistungen und erhalte Zugang zu relevanten
                Kundenanfragen.
              </p>

              <div className="mt-9 flex flex-col gap-4 sm:flex-row">
                <Link
                  href="/anbieter-registrieren"
                  className="group relative inline-flex min-h-[62px] items-center justify-center overflow-hidden rounded-2xl bg-gradient-to-r from-sky-400 via-indigo-500 to-fuchsia-500 px-8 font-black shadow-[0_24px_80px_rgba(76,75,255,0.4)] transition duration-300 hover:-translate-y-1 hover:shadow-[0_34px_100px_rgba(76,75,255,0.58)]"
                >
                  <span className="absolute inset-y-0 -left-24 w-16 rotate-12 bg-white/25 blur-2xl transition duration-700 group-hover:left-[120%]" />

                  <span className="relative flex items-center gap-3">
                    {tr("Kostenlos als Anbieter registrieren")}
                    <span className="text-xl transition group-hover:translate-x-1">
                      →
                    </span>
                  </span>
                </Link>

                <Link
                  href="/anbieter"
                  className="inline-flex min-h-[62px] items-center justify-center rounded-2xl border border-white/10 bg-white/[0.04] px-8 font-black transition duration-300 hover:-translate-y-1 hover:border-white/20 hover:bg-white/[0.07]"
                >
                  {tr("So funktioniert es")}
                </Link>
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              {benefits.map((benefit, index) => (
                <div
                  key={benefit}
                  className="group rounded-[24px] border border-white/[0.08] bg-black/20 p-5 transition duration-300 hover:-translate-y-1 hover:border-sky-300/20 hover:bg-sky-400/[0.05]"
                >
                  <div className="flex items-center justify-between">
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-emerald-300/20 bg-emerald-400/10 font-black text-emerald-300">
                      ✓
                    </span>

                    <span className="text-xs font-black text-white/[0.1]">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                  </div>

                  <p className="mt-5 font-black leading-6">
                    {benefit}
                  </p>
                </div>
              ))}

              <div className="sm:col-span-2 rounded-[24px] border border-sky-300/15 bg-gradient-to-r from-sky-400/[0.08] to-violet-400/[0.08] p-5">
                <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="text-xs font-black uppercase tracking-[0.18em] text-sky-300">
                      {tr("Auftrago Anbieter-Netzwerk")}
                    </p>
                    <p className="mt-2 text-xl font-black tracking-[-0.03em]">
                      {tr("Jetzt Teil der Plattform werden")}
                    </p>
                  </div>

                  <div className="flex -space-x-3">
                    {["🧑‍🔧", "👷", "🧑‍💼", "👨‍🔧"].map(
                      (avatar, index) => (
                        <span
                          key={`${avatar}-${index}`}
                          className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-[#0c1426] bg-slate-800 text-lg"
                        >
                          {avatar}
                        </span>
                      )
                    )}

                    <span className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-[#0c1426] bg-gradient-to-br from-sky-400 to-violet-500 text-xs font-black">
                      +++
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-px overflow-hidden rounded-[30px] border border-white/[0.08] bg-white/[0.08] lg:grid-cols-4">
          {[
            ["420+", tr("Servizi")],
            ["26", tr("Cantoni")],
            [tr("Täglich"), tr("Neue Anfragen")],
            [tr("Direkt"), tr("Zum Kundenkontakt")],
          ].map(([value, label]) => (
            <div
              key={label}
              className="bg-[#070d19] px-5 py-7 text-center transition hover:bg-white/[0.035]"
            >
              <strong className="block text-2xl font-black tracking-[-0.04em] text-white sm:text-3xl">
                {value}
              </strong>

              <span className="mt-1 block text-xs font-bold text-slate-500 sm:text-sm">
                {label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
