"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

import {
  ArrowRight,
  BadgeCheck,
  CheckCircle2,
  Clock3,
  Heart,
  Shield,
  Hammer,
  Laptop,
  MapPin,
  Search,
  ShieldCheck,
  Sparkles,
  Trees,
  Truck,
  Wrench,
} from "lucide-react";
import styles from "./Hero.module.css";

import { homeTranslations } from "@/lib/home-i18n";
import type { Locale } from "@/lib/i18n/config";
import { translateHomeText } from "@/lib/i18n/home-translator";
const categories = [
  { label: "Reinigung", icon: Sparkles, tone: "blue" },
  { label: "Handwerker", icon: Hammer, tone: "cyan" },
  { label: "Umzug & Transport", icon: Truck, tone: "cyan" },
  { label: "Garten & Umgebung", icon: Trees, tone: "green" },
  { label: "Sanitär", icon: Wrench, tone: "orange" },
  { label: "IT & Technik", icon: Laptop, tone: "violet" },
  { label: "Versicherungen", icon: Shield, tone: "gold", featured: true },
  { label: "Salute", icon: Heart, tone: "pink" },
  { label: "Alle Services", icon: Sparkles, tone: "magenta" },
];

const mapPoints = [
  [56, 98],
  [88, 78],
  [119, 91],
  [151, 73],
  [181, 91],
  [210, 82],
  [241, 102],
  [268, 111],
  [102, 121],
  [143, 116],
  [183, 127],
  [220, 119],
];

const particles = Array.from({ length: 18 }, (_, index) => index);

export default function Hero({ locale }: { locale: Locale }) {
const tr = (value: string) => translateHomeText(locale, value);
  const t = homeTranslations[locale] ?? homeTranslations.de;

  const router = useRouter();
  const [searchValue, setSearchValue] = useState("");

  function handleStartOrder(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const query = searchValue.trim();
    const target = query
      ? `/auftrag-erstellen?beschreibung=${encodeURIComponent(query)}`
      : "/auftrag-erstellen";

    router.push(target);
  }

  return (
    <section className={styles.hero}>
      <div className={styles.backgroundGrid} />
      <div className={styles.aurora} />
      <div className={styles.glowBlue} />
      <div className={styles.glowPurple} />
      <div className={styles.glowPink} />

      <div className={styles.particles} aria-hidden="true">
        {particles.map((particle) => (
          <i key={particle} />
        ))}
      </div>

      <div className={styles.container}>
        <div className={styles.heroGrid}>
          <div className={styles.content}>
            <div className={styles.topBadge}>
              <span className={styles.badgePulse} />
              <span className={styles.swissIcon}>✚</span>
              {t.badge}
            </div>

            <h1 className={styles.title}>
              {t.title1}
              <br />
              {t.title2.split(" ")[0]}{" "}
        <span>{t.title2.split(" ").slice(1).join(" ")}</span>
            </h1>

            <p className={styles.description}>
              Che si tratti di pulizie, artigiani, traslochi o assicurazioni – ti mettiamo in contatto con fornitori verificati della tua regione. Rapido, gratuito e senza impegno.
            </p>

            <div className={styles.benefits}>
              <span>
                <CheckCircle2 size={18} />
                {t.free}
              </span>
              <span>
                <Clock3 size={18} />
                {t.fast}
              </span>
              <span>
                <ShieldCheck size={18} />
                {t.verified}
              </span>
              <span>
                <span className={styles.miniSwiss}>✚</span>
                {t.nationwide}
              </span>
            </div>

            <form className={styles.searchBox} onSubmit={handleStartOrder}>
              <div className={styles.searchPulse} />
              <div className={styles.searchIconBox}>
                <Search size={29} />
              </div>

              <input
                type="text"
                name="auftrago-search"
                value={searchValue}
                onChange={(event) => setSearchValue(event.target.value)}
                placeholder={t["Was möchtest du erledigen lassen?"]}
                className={styles.searchInput}
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="none"
                spellCheck={false}
              />

              <button type="submit" className={styles.searchButton}>
                <span>{t.start}</span>
                <ArrowRight size={21} />
              </button>
            </form>

            <div className={styles.popular}>
              <span>{t["Beliebte Dienstleistungen"]}:</span>
              <button>🧹 {t["Reinigung"]}</button>
              <button>🔨 {t["Handwerker"]}</button>
              <button>🚚 {t["Umzug"]}</button>
              <button>🌿 {t["Gartenpflege"]}</button>
              <button
                type="button"
                className={styles.insurancePopular}
                onClick={() => router.push("/auftrag-erstellen?kategorie=Assicurazioni")}
              >
                🛡️ {t["Versicherungen"]} <span>{tr("Neu")}</span>
              </button>
            </div>
          </div>

          <div className={styles.matchPanel}>
            <div className={styles.panelOrbitOne} />
            <div className={styles.panelOrbitTwo} />
            <div className={styles.panelGlow} />

            <div className={styles.panel}>
              <div className={styles.scannerLine} />

              <div className={styles.panelHeader}>
                <div className={styles.botIcon}>🤖</div>

                <div>
                  <span>{t.liveMatching}</span>
                  <strong>{t.distributing}</strong>
                </div>

                <div className={styles.liveBadge}>
                  <i />
                  Live
                </div>
              </div>

              <div className={styles.requestMapCard}>
                <div className={styles.requestText}>
                  <span>{t.request}</span>
                  <strong>
                    {t["Wohnungsreinigung in Aarau"]},
                    <br />
                    {tr("Termin flexibel")}
                  </strong>
                </div>

                <div className={styles.swissMap} aria-hidden="true">
                  <svg viewBox="0 0 320 190">
                    <defs>
                      <linearGradient id="mapStroke" x1="0" x2="1">
                        <stop offset="0" stopColor="#2ba9ff" />
                        <stop offset="1" stopColor="#a54dff" />
                      </linearGradient>
                      <filter id="mapGlow">
                        <feGaussianBlur stdDeviation="4" result="blur" />
                        <feMerge>
                          <feMergeNode in="blur" />
                          <feMergeNode in="SourceGraphic" />
                        </feMerge>
                      </filter>
                    </defs>

                    <path
                      className={styles.mapOutline}
                      d="M24 106 43 91 57 70 77 67 92 48 112 55 124 43 142 52 159 39 178 47 193 61 213 58 229 73 250 72 260 88 286 91 294 108 279 118 265 137 244 134 228 145 205 141 192 153 171 145 150 155 133 143 111 147 94 132 74 138 61 125 43 126 31 116Z"
                      fill="rgba(67,92,188,.18)"
                      stroke="url(#mapStroke)"
                      strokeWidth="2"
                    />

                    {mapPoints.map(([cx, cy], index) => (
                      <g
                        key={index}
                        filter="url(#mapGlow)"
                        className={styles.mapPoint}
                        style={{ animationDelay: `${index * 0.12}s` }}
                      >
                        <circle
                          cx={cx}
                          cy={cy}
                          r="9"
                          fill="rgba(111,74,255,.2)"
                        />
                        <circle cx={cx} cy={cy} r="3.4" fill="#7e63ff" />
                      </g>
                    ))}

                    <g filter="url(#mapGlow)" className={styles.mainMapPoint}>
                      <circle
                        cx="162"
                        cy="95"
                        r="25"
                        fill="rgba(214,49,255,.14)"
                      />
                      <circle
                        cx="162"
                        cy="95"
                        r="13"
                        fill="rgba(158,69,255,.26)"
                      />
                      <circle cx="162" cy="95" r="5" fill="#ef4dff" />
                    </g>
                  </svg>
                </div>
              </div>

              <div className={styles.matchRows}>
                <div className={styles.matchRow}>
                  <span className={styles.matchIcon}>
                    <CheckCircle2 size={19} />
                  </span>
                  <div>
                    <strong>{t.serviceDetected}</strong>
                    <small>{t["Wohnungsreinigung"]}</small>
                  </div>
                </div>

                <div className={styles.matchRow}>
                  <span className={`${styles.matchIcon} ${styles.violetBg}`}>
                    <MapPin size={19} />
                  </span>
                  <div>
                    <strong>{t.regionDetected}</strong>
                    <small>{t["Aarau und Umgebung"]}</small>
                  </div>
                </div>

                <div className={styles.matchRow}>
                  <span className={`${styles.matchIcon} ${styles.blueBg}`}>
                    <BadgeCheck size={19} />
                  </span>
                  <div>
                    <strong>{t.providersFound}</strong>
                    <small>{t.providersAvailable}</small>
                  </div>
                </div>
              </div>

              <button className={styles.resultButton}>
                <span>{t.viewProviders}</span>
                <ArrowRight size={21} />
                <span className={styles.avatarStack}>
                  <i>DC</i>
                  <i>LS</i>
                  <i>AK</i>
                  <b>+9</b>
                </span>
              </button>
            </div>
          </div>
        </div>

        <div className={styles.categoryHeader}>
          <h2>{t["Alle Dienstleistungen"]}</h2>
          <span>{t["Passende Leistungen festlegen"]}</span>
        </div>

        <div className={styles.categories}>
          {categories.map(({ label, icon: Icon, tone }, index) => (
            <button
              key={tr(label)}
              className={styles.categoryCard}
              style={{ animationDelay: `${index * 0.08}s` }}
            >
              <span className={styles.cardGlow} />
              <Icon className={styles[tone]} size={34} strokeWidth={1.8} />
              <span>{tr(label)}</span>
            </button>
          ))}
        </div>

        <div className={styles.statsBar}>
          <div>
            <strong>420+</strong>
            <span>{"Servizi"}</span>
          </div>
          <div>
            <strong>6&apos;500+</strong>
            <span>{"Fornitori"}</span>
          </div>
          <div>
            <strong>38&apos;000+</strong>
            <span>{"Incarichi assegnati"}</span>
          </div>
          <div>
            <strong>26</strong>
            <span>{"Cantoni"}</span>
          </div>
          <div className={styles.ratingBlock}>
            <span className={styles.stars}>★★★★★</span>
            <strong>4.9/5</strong>
            <small>Von über 2&apos;400 Kunden bewertet</small>
          </div>
        </div>
      </div>
    </section>
  );
}