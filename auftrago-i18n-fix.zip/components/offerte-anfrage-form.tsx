"use client";

import {
  useEffect,
  useMemo,
  useState,
  type FormEvent,
} from "react";

import QuoteSuccess from "@/components/wizard/quote-success";

import ServiceSelector from "@/components/wizard/service-selector";
import {
  getServiceByTitle,
  type ServiceDefinition,
} from "@/lib/services/index";

type TrackingData = {
  landingPage: string;
  currentPage: string;
  utmSource: string;
  utmMedium: string;
  utmCampaign: string;
  utmTerm: string;
  utmContent: string;
  gclid: string;
  fbclid: string;
};

type WizardData = {
  service: string;

  postalCode: string;
  city: string;

  objectType: string;
  rooms: string;
  area: string;
  bathrooms: string;
  windows: string;
  floor: string;
  elevator: string;

  balcony: boolean;
  cellar: boolean;
  garage: boolean;
  blinds: boolean;
  handoverGuarantee: boolean;
  pets: boolean;

  movingFrom: string;
  movingTo: string;
  movingFromFloor: string;
  movingToFloor: string;
  movingFromElevator: string;
  movingToElevator: string;
  assembly: boolean;
  packing: boolean;
  disposal: boolean;

  gardenArea: string;
  lawn: boolean;
  hedge: boolean;
  trees: boolean;
  recurring: boolean;

  paintingType: string;
  paintingRooms: string;
  paintingArea: string;

  electricalType: string;
  sanitaryType: string;

  urgency: string;
  desiredDate: string;
  flexibleDate: boolean;

  message: string;

  name: string;
  phone: string;
  email: string;

  privacyAccepted: boolean;
};

type ServiceOption = {
  id: string;
  title: string;
  icon: string;
  description: string;
};

declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void;
  }
}

const INITIAL_TRACKING: TrackingData = {
  landingPage: "",
  currentPage: "",
  utmSource: "",
  utmMedium: "",
  utmCampaign: "",
  utmTerm: "",
  utmContent: "",
  gclid: "",
  fbclid: "",
};

const INITIAL_DATA: WizardData = {
  service: "",

  postalCode: "",
  city: "",

  objectType: "",
  rooms: "",
  area: "",
  bathrooms: "",
  windows: "",
  floor: "",
  elevator: "",

  balcony: false,
  cellar: false,
  garage: false,
  blinds: false,
  handoverGuarantee: false,
  pets: false,

  movingFrom: "",
  movingTo: "",
  movingFromFloor: "",
  movingToFloor: "",
  movingFromElevator: "",
  movingToElevator: "",
  assembly: false,
  packing: false,
  disposal: false,

  gardenArea: "",
  lawn: false,
  hedge: false,
  trees: false,
  recurring: false,

  paintingType: "",
  paintingRooms: "",
  paintingArea: "",

  electricalType: "",
  sanitaryType: "",

  urgency: "",
  desiredDate: "",
  flexibleDate: false,

  message: "",

  name: "",
  phone: "",
  email: "",

  privacyAccepted: false,
};

const SERVICES: ServiceOption[] = [
  {
    id: "Reinigung",
    title: "Reinigung",
    icon: "🧹",
    description: "Wohnung, Haus, Büro oder Gewerbe",
  },
  {
    id: "Umzugsreinigung",
    title: "Umzugsreinigung",
    icon: "🏠",
    description: "Mit oder ohne Abgabegarantie",
  },
  {
    id: "Fensterreinigung",
    title: "Fensterreinigung",
    icon: "🪟",
    description: "Fenster, Rahmen und Storen",
  },
  {
    id: "Umzug",
    title: "Umzug",
    icon: "🚚",
    description: "Privat- oder Firmenumzug",
  },
  {
    id: "Transport",
    title: "Transport",
    icon: "📦",
    description: "Möbel, Waren und Kleintransporte",
  },
  {
    id: "Entsorgung",
    title: "Entsorgung",
    icon: "♻️",
    description: "Räumung, Sperrgut und Entsorgung",
  },
  {
    id: "Gartenpflege",
    title: "Gartenpflege",
    icon: "🌿",
    description: "Rasen, Hecken, Bäume und Unterhalt",
  },
  {
    id: "Hauswartung",
    title: "Hauswartung",
    icon: "🏢",
    description: "Liegenschaftsbetreuung und Unterhalt",
  },
  {
    id: "Malerarbeiten",
    title: "Malerarbeiten",
    icon: "🎨",
    description: "Innen, aussen und Renovationen",
  },
  {
    id: "Elektriker",
    title: "Elektriker",
    icon: "⚡",
    description: "Installation, Reparatur und Störung",
  },
  {
    id: "Sanitär",
    title: "Sanitär",
    icon: "🚿",
    description: "Bad, WC, Leitungen und Boiler",
  },
];

const STEPS = [
  {
    id: 1,
    label: "Dienstleistung",
  },
  {
    id: 2,
    label: "Standort",
  },
  {
    id: 3,
    label: "Details",
  },
  {
    id: 4,
    label: "Termin",
  },
  {
    id: 5,
    label: "Kontakt",
  },
  {
    id: 6,
    label: "Prüfen",
  },
];

function getTrackingData(): TrackingData {
  if (typeof window === "undefined") {
    return INITIAL_TRACKING;
  }

  const url = new URL(window.location.href);
  const params = url.searchParams;

  const existingLandingPage =
    sessionStorage.getItem(
      "auftrago_landing_page",
    );

  const landingPage =
    existingLandingPage ||
    window.location.href;

  if (!existingLandingPage) {
    sessionStorage.setItem(
      "auftrago_landing_page",
      landingPage,
    );
  }

  const tracking: TrackingData = {
    landingPage,

    currentPage:
      window.location.href,

    utmSource:
      params.get("utm_source") ||
      sessionStorage.getItem(
        "auftrago_utm_source",
      ) ||
      "",

    utmMedium:
      params.get("utm_medium") ||
      sessionStorage.getItem(
        "auftrago_utm_medium",
      ) ||
      "",

    utmCampaign:
      params.get("utm_campaign") ||
      sessionStorage.getItem(
        "auftrago_utm_campaign",
      ) ||
      "",

    utmTerm:
      params.get("utm_term") ||
      sessionStorage.getItem(
        "auftrago_utm_term",
      ) ||
      "",

    utmContent:
      params.get("utm_content") ||
      sessionStorage.getItem(
        "auftrago_utm_content",
      ) ||
      "",

    gclid:
      params.get("gclid") ||
      sessionStorage.getItem(
        "auftrago_gclid",
      ) ||
      "",

    fbclid:
      params.get("fbclid") ||
      sessionStorage.getItem(
        "auftrago_fbclid",
      ) ||
      "",
  };

  sessionStorage.setItem(
    "auftrago_utm_source",
    tracking.utmSource,
  );

  sessionStorage.setItem(
    "auftrago_utm_medium",
    tracking.utmMedium,
  );

  sessionStorage.setItem(
    "auftrago_utm_campaign",
    tracking.utmCampaign,
  );

  sessionStorage.setItem(
    "auftrago_utm_term",
    tracking.utmTerm,
  );

  sessionStorage.setItem(
    "auftrago_utm_content",
    tracking.utmContent,
  );

  sessionStorage.setItem(
    "auftrago_gclid",
    tracking.gclid,
  );

  sessionStorage.setItem(
    "auftrago_fbclid",
    tracking.fbclid,
  );

  return tracking;
}

function trackEvent(
  eventName: string,
  parameters: Record<
    string,
    string | number | boolean
  > = {},
) {
  if (
    typeof window !== "undefined" &&
    typeof window.gtag === "function"
  ) {
    window.gtag(
      "event",
      eventName,
      parameters,
    );
  }
}

function booleanLabel(value: boolean) {
  return value ? "Ja" : "Nein";
}

function clean(value: string) {
  return value.trim();
}

function getSelectedService(
  serviceId: string,
) {
  return SERVICES.find(
    (service) => service.id === serviceId,
  );
}

function isCleaningService(
  service: string,
) {
  return [
    "Reinigung",
    "Umzugsreinigung",
    "Fensterreinigung",
    "Hauswartung",
  ].includes(service);
}

function isMovingService(
  service: string,
) {
  return [
    "Umzug",
    "Transport",
    "Entsorgung",
  ].includes(service);
}

function createDetailedMessage(
  data: WizardData,
) {
  const lines: string[] = [];

  lines.push(
    `Dienstleistung: ${data.service}`,
  );

  lines.push(
    `Standort: ${data.postalCode} ${data.city}`,
  );

  if (data.objectType) {
    lines.push(
      `Objekt: ${data.objectType}`,
    );
  }

  if (isCleaningService(data.service)) {
    if (data.rooms) {
      lines.push(
        `Zimmer: ${data.rooms}`,
      );
    }

    if (data.area) {
      lines.push(
        `Fläche: ${data.area} m²`,
      );
    }

    if (data.bathrooms) {
      lines.push(
        `Bäder/WC: ${data.bathrooms}`,
      );
    }

    if (data.windows) {
      lines.push(
        `Fenster: ${data.windows}`,
      );
    }

    if (data.floor) {
      lines.push(
        `Etage: ${data.floor}`,
      );
    }

    if (data.elevator) {
      lines.push(
        `Lift: ${data.elevator}`,
      );
    }

    lines.push(
      `Balkon: ${booleanLabel(data.balcony)}`,
    );

    lines.push(
      `Keller: ${booleanLabel(data.cellar)}`,
    );

    lines.push(
      `Garage: ${booleanLabel(data.garage)}`,
    );

    lines.push(
      `Lamellenstoren: ${booleanLabel(data.blinds)}`,
    );

    lines.push(
      `Abgabegarantie: ${booleanLabel(data.handoverGuarantee)}`,
    );

    lines.push(
      `Haustiere: ${booleanLabel(data.pets)}`,
    );
  }

  if (isMovingService(data.service)) {
    if (data.movingFrom) {
      lines.push(
        `Abholadresse: ${data.movingFrom}`,
      );
    }

    if (data.movingTo) {
      lines.push(
        `Zieladresse: ${data.movingTo}`,
      );
    }

    if (data.movingFromFloor) {
      lines.push(
        `Etage Abholort: ${data.movingFromFloor}`,
      );
    }

    if (data.movingToFloor) {
      lines.push(
        `Etage Zielort: ${data.movingToFloor}`,
      );
    }

    if (data.movingFromElevator) {
      lines.push(
        `Lift Abholort: ${data.movingFromElevator}`,
      );
    }

    if (data.movingToElevator) {
      lines.push(
        `Lift Zielort: ${data.movingToElevator}`,
      );
    }

    lines.push(
      `Montage/Demontage: ${booleanLabel(data.assembly)}`,
    );

    lines.push(
      `Verpackungsservice: ${booleanLabel(data.packing)}`,
    );

    lines.push(
      `Entsorgung: ${booleanLabel(data.disposal)}`,
    );
  }

  if (data.service === "Gartenpflege") {
    if (data.gardenArea) {
      lines.push(
        `Gartenfläche: ${data.gardenArea} m²`,
      );
    }

    lines.push(
      `Rasenpflege: ${booleanLabel(data.lawn)}`,
    );

    lines.push(
      `Heckenschnitt: ${booleanLabel(data.hedge)}`,
    );

    lines.push(
      `Baumarbeiten: ${booleanLabel(data.trees)}`,
    );

    lines.push(
      `Wiederkehrender Auftrag: ${booleanLabel(data.recurring)}`,
    );
  }

  if (data.service === "Malerarbeiten") {
    if (data.paintingType) {
      lines.push(
        `Malerarbeiten: ${data.paintingType}`,
      );
    }

    if (data.paintingRooms) {
      lines.push(
        `Anzahl Räume: ${data.paintingRooms}`,
      );
    }

    if (data.paintingArea) {
      lines.push(
        `Zu streichende Fläche: ${data.paintingArea} m²`,
      );
    }
  }

  if (
    data.service === "Elektriker" &&
    data.electricalType
  ) {
    lines.push(
      `Elektriker-Arbeit: ${data.electricalType}`,
    );
  }

  if (
    data.service === "Sanitär" &&
    data.sanitaryType
  ) {
    lines.push(
      `Sanitär-Arbeit: ${data.sanitaryType}`,
    );
  }

  if (data.urgency) {
    lines.push(
      `Dringlichkeit: ${data.urgency}`,
    );
  }

  if (data.desiredDate) {
    lines.push(
      `Wunschdatum: ${data.desiredDate}`,
    );
  }

  lines.push(
    `Termin flexibel: ${booleanLabel(data.flexibleDate)}`,
  );

  if (data.message) {
    lines.push("");
    lines.push("Zusätzliche Beschreibung:");
    lines.push(data.message);
  }

  return lines.join("\n");
}

export default function OfferteAnfrageForm() {
  const [step, setStep] = useState(1);

  const [data, setData] =
    useState<WizardData>(INITIAL_DATA);

  const [tracking, setTracking] =
    useState<TrackingData>(
      INITIAL_TRACKING,
    );

  const [sending, setSending] =
    useState(false);

  const [sent, setSent] =
    useState(false);

  const [error, setError] =
    useState("");

  useEffect(() => {
    setTracking(getTrackingData());

    trackEvent(
      "quote_wizard_view",
      {
        form_name:
          "offerte_anfragen_wizard",
      },
    );
  }, []);

  const selectedService = useMemo(
    () => getServiceByTitle(data.service),
    [data.service],
  );

  const progress =
    (step / STEPS.length) * 100;

  function updateField<
    Key extends keyof WizardData,
  >(
    key: Key,
    value: WizardData[Key],
  ) {
    setData((current) => ({
      ...current,
      [key]: value,
    }));

    setError("");
  }

  function validateStep() {
    if (step === 1 && !data.service) {
      return "Bitte wähle eine Dienstleistung.";
    }

    if (
      step === 2 &&
      (!clean(data.postalCode) ||
        !clean(data.city))
    ) {
      return "Bitte gib PLZ und Ort ein.";
    }

    if (
      step === 3 &&
      !clean(data.message)
    ) {
      return "Bitte beschreibe deinen Auftrag kurz.";
    }

    if (
      step === 4 &&
      !data.urgency &&
      !data.desiredDate
    ) {
      return "Bitte wähle einen gewünschten Zeitraum oder ein Datum.";
    }

    if (
      step === 5 &&
      (!clean(data.name) ||
        !clean(data.phone) ||
        !clean(data.email))
    ) {
      return "Bitte fülle Name, Telefon und E-Mail aus.";
    }

    if (
      step === 5 &&
      !data.email.includes("@")
    ) {
      return "Bitte gib eine gültige E-Mail-Adresse ein.";
    }

    if (
      step === 5 &&
      !data.privacyAccepted
    ) {
      return "Bitte bestätige die Datenschutzhinweise.";
    }

    return "";
  }

  function goNext() {
    const validationError =
      validateStep();

    if (validationError) {
      setError(validationError);
      return;
    }

    const nextStep = Math.min(
      step + 1,
      STEPS.length,
    );

    trackEvent(
      "quote_wizard_step_complete",
      {
        form_name:
          "offerte_anfragen_wizard",

        completed_step:
          step,

        next_step:
          nextStep,

        service:
          data.service || "unknown",
      },
    );

    setStep(nextStep);
    setError("");

    document
      .getElementById("quote-form")
      ?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
  }

  function goBack() {
    setStep((current) =>
      Math.max(1, current - 1),
    );

    setError("");
  }

  async function handleSubmit(
    event: FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault();

    if (sending) {
      return;
    }

    const validationError =
      validateStep();

    if (validationError) {
      setError(validationError);
      return;
    }

    setSending(true);
    setError("");

    const latestTracking =
      getTrackingData();

    const detailedMessage =
      createDetailedMessage(data);

    const payload = {
      name: clean(data.name),
      phone: clean(data.phone),
      email: clean(data.email).toLowerCase(),

      salutation: "Nicht angegeben",
      street: "Nicht angegeben",

      postalCode:
        clean(data.postalCode),

      city:
        clean(data.city),

      region:
        clean(data.city) ||
        clean(data.postalCode) ||
        "Nicht angegeben",

      service:
        data.service,

      start:
        data.desiredDate ||
        data.urgency ||
        "Nach Absprache",

      flexibleDate:
        data.flexibleDate
          ? "Ja"
          : "Nein",

      viewingWanted:
        "Nach Absprache",

      phoneAvailability:
        "Nach Absprache",

      objectType:
        data.objectType ||
        "Nicht angegeben",

      propertyType:
        data.objectType ||
        "Nicht angegeben",

      floor:
        data.floor ||
        data.movingFromFloor ||
        "Nicht angegeben",

      elevator:
        data.elevator ||
        data.movingFromElevator ||
        "Nicht angegeben",

      parking:
        data.garage
          ? "Garage vorhanden"
          : "Nicht angegeben",

      rooms:
        data.rooms ||
        data.paintingRooms ||
        "Nicht angegeben",

      area:
        data.area ||
        data.gardenArea ||
        data.paintingArea ||
        "Nicht angegeben",

      windows:
        data.windows ||
        "Nicht angegeben",

      windowSize:
        "Nicht angegeben",

      blinds:
        data.blinds
          ? "Ja"
          : "Nein",

      shutters:
        "Nicht angegeben",

      handoverGuarantee:
        data.handoverGuarantee
          ? "Ja"
          : "Nein",

      cellar:
        data.cellar
          ? "Ja"
          : "Nein",

      balcony:
        data.balcony
          ? "Ja"
          : "Nein",

      carpetCleaning:
        "Nicht angegeben",

      budget:
        "Nicht angegeben",

      offersWanted:
        "3 Angebote",

      important:
        "Preis, Qualität und schnelle Rückmeldung",

      message:
        detailedMessage,

      landingPage:
        latestTracking.landingPage,

      currentPage:
        latestTracking.currentPage,

      utmSource:
        latestTracking.utmSource,

      utmMedium:
        latestTracking.utmMedium,

      utmCampaign:
        latestTracking.utmCampaign,

      utmTerm:
        latestTracking.utmTerm,

      utmContent:
        latestTracking.utmContent,

      gclid:
        latestTracking.gclid,

      fbclid:
        latestTracking.fbclid,
    };

    try {
      const response = await fetch(
        "/api/anfrage",
        {
          method: "POST",

          headers: {
            "Content-Type":
              "application/json",
          },

          body:
            JSON.stringify(payload),
        },
      );

      const result =
        await response
          .json()
          .catch(() => null);

      if (
        !response.ok ||
        !result?.ok
      ) {
        throw new Error(
          result?.error ||
          result?.warning ||
          "Die Anfrage konnte nicht gesendet werden.",
        );
      }

      trackEvent(
        "generate_lead",
        {
          currency: "CHF",
          value: 1,

          form_name:
            "offerte_anfragen_wizard",

          lead_source:
            payload.utmSource ||
            "website",

          service:
            payload.service,

          region:
            payload.region,

          city:
            payload.city,

          landing_page:
            payload.landingPage,

          current_page:
            payload.currentPage,

          utm_source:
            payload.utmSource,

          utm_medium:
            payload.utmMedium,

          utm_campaign:
            payload.utmCampaign,
        },
      );

      setSent(true);

      sessionStorage.removeItem(
        "auftrago_quote_wizard",
      );
    } catch (submitError) {
      console.error(
        "QUOTE SUBMISSION ERROR:",
        submitError,
      );

      setError(
        submitError instanceof Error
          ? submitError.message
          : "Technischer Fehler. Bitte versuche es nochmals.",
      );
    } finally {
      setSending(false);
    }
  }

  if (sent) {
    return (
      <QuoteSuccess
        name={data.name}
        service={data.service}
        postalCode={data.postalCode}
        city={data.city}
        appointment={
          data.desiredDate ||
          data.urgency ||
          "Nach Absprache"
        }
      />
    );
  }

  return (
    <>
      <form
        className="premium-wizard"
        onSubmit={handleSubmit}
      >
        <div className="wizard-progress-top">
          <div>
            <span>
              Schritt {step} von {STEPS.length}
            </span>

            <strong>
              {STEPS[step - 1]?.label}
            </strong>
          </div>

          <span className="progress-percent">
            {Math.round(progress)} %
          </span>
        </div>

        <div className="progress-track">
          <div
            className="progress-fill"
            style={{
              width: `${progress}%`,
            }}
          />
        </div>

        <div className="wizard-step-dots">
          {STEPS.map((wizardStep) => (
            <button
              key={wizardStep.id}
              type="button"
              className={[
                "wizard-step-dot",
                step === wizardStep.id
                  ? "wizard-step-dot-active"
                  : "",
                step > wizardStep.id
                  ? "wizard-step-dot-complete"
                  : "",
              ].join(" ")}
              disabled={
                wizardStep.id > step
              }
              onClick={() => {
                if (
                  wizardStep.id < step
                ) {
                  setStep(
                    wizardStep.id,
                  );
                }
              }}
            >
              <span>
                {step > wizardStep.id
                  ? "✓"
                  : wizardStep.id}
              </span>

              <small>
                {wizardStep.label}
              </small>
            </button>
          ))}
        </div>

        <div
          key={step}
          className="wizard-content"
        >
          {step === 1 ? (
            <section>
              <p className="wizard-kicker">
                Auftrag starten
              </p>

              <h2>
                Welche Dienstleistung
                <span> benötigst du?</span>
              </h2>

              <p className="wizard-description">
                Suche direkt nach einer Dienstleistung oder wähle zuerst
                eine Kategorie. Nach deiner Auswahl geht es automatisch
                zum Standort weiter.
              </p>

              <ServiceSelector
                value={data.service}
                onSelect={(service: ServiceDefinition) => {
                  updateField("service", service.title);

                  trackEvent(
                    "quote_service_selected",
                    {
                      service: service.title,
                      service_slug: service.slug,
                      service_category: service.category,
                    },
                  );

                  window.setTimeout(() => {
                    setStep(2);
                    setError("");

                    document
                      .getElementById("quote-form")
                      ?.scrollIntoView({
                        behavior: "smooth",
                        block: "start",
                      });
                  }, 180);
                }}
              />
            </section>
          ) : null}

          {step === 2 ? (
            <section>
              <p className="wizard-kicker">
                Einsatzort
              </p>

              <h2>
                Wo findet der
                <span> Auftrag statt?</span>
              </h2>

              <p className="wizard-description">
                Mit PLZ und Ort kann deine
                Anfrage regional zugeordnet werden.
              </p>

              <div className="wizard-card">
                <div className="location-icon">
                  📍
                </div>

                <div className="field-grid field-grid-location">
                  <label>
                    <span>Postleitzahl *</span>

                    <input
                      value={data.postalCode}
                      inputMode="numeric"
                      maxLength={4}
                      placeholder="z. B. 8001"
                      onChange={(event) =>
                        updateField(
                          "postalCode",
                          event.target.value,
                        )
                      }
                    />
                  </label>

                  <label>
                    <span>Ort *</span>

                    <input
                      value={data.city}
                      placeholder="z. B. Zürich"
                      onChange={(event) =>
                        updateField(
                          "city",
                          event.target.value,
                        )
                      }
                    />
                  </label>
                </div>

                {data.postalCode &&
                data.city ? (
                  <div className="location-confirmation">
                    <span>✓</span>

                    <div>
                      <strong>
                        Standort erfasst
                      </strong>

                      <small>
                        {data.postalCode}{" "}
                        {data.city}
                      </small>
                    </div>
                  </div>
                ) : null}
              </div>
            </section>
          ) : null}

          {step === 3 ? (
            <section>
              <p className="wizard-kicker">
                Auftragsdetails
              </p>

              <h2>
                Erzähle uns mehr
                <span> über den Auftrag.</span>
              </h2>

              <p className="wizard-description">
                Genauere Angaben ermöglichen
                passendere Rückmeldungen und
                realistischere Offerten.
              </p>

              {isCleaningService(
                data.service,
              ) ? (
                <div className="wizard-card">
                  <div className="field-grid">
                    <label>
                      <span>Objektart</span>

                      <select
                        value={data.objectType}
                        onChange={(event) =>
                          updateField(
                            "objectType",
                            event.target.value,
                          )
                        }
                      >
                        <option value="">
                          Bitte wählen
                        </option>
                        <option value="Wohnung">
                          Wohnung
                        </option>
                        <option value="Einfamilienhaus">
                          Einfamilienhaus
                        </option>
                        <option value="Mehrfamilienhaus">
                          Mehrfamilienhaus
                        </option>
                        <option value="Büro">
                          Büro
                        </option>
                        <option value="Gewerbe">
                          Gewerbe
                        </option>
                      </select>
                    </label>

                    <label>
                      <span>Anzahl Zimmer</span>

                      <input
                        value={data.rooms}
                        placeholder="z. B. 4.5"
                        onChange={(event) =>
                          updateField(
                            "rooms",
                            event.target.value,
                          )
                        }
                      />
                    </label>

                    <label>
                      <span>Fläche in m²</span>

                      <input
                        value={data.area}
                        inputMode="numeric"
                        placeholder="z. B. 120"
                        onChange={(event) =>
                          updateField(
                            "area",
                            event.target.value,
                          )
                        }
                      />
                    </label>

                    <label>
                      <span>Bäder / WC</span>

                      <input
                        value={data.bathrooms}
                        inputMode="numeric"
                        placeholder="z. B. 2"
                        onChange={(event) =>
                          updateField(
                            "bathrooms",
                            event.target.value,
                          )
                        }
                      />
                    </label>

                    <label>
                      <span>Fensteranzahl</span>

                      <input
                        value={data.windows}
                        placeholder="z. B. 11–15"
                        onChange={(event) =>
                          updateField(
                            "windows",
                            event.target.value,
                          )
                        }
                      />
                    </label>

                    <label>
                      <span>Etage</span>

                      <input
                        value={data.floor}
                        placeholder="z. B. 3. Etage"
                        onChange={(event) =>
                          updateField(
                            "floor",
                            event.target.value,
                          )
                        }
                      />
                    </label>

                    <label>
                      <span>Lift vorhanden?</span>

                      <select
                        value={data.elevator}
                        onChange={(event) =>
                          updateField(
                            "elevator",
                            event.target.value,
                          )
                        }
                      >
                        <option value="">
                          Bitte wählen
                        </option>
                        <option value="Ja">
                          Ja
                        </option>
                        <option value="Nein">
                          Nein
                        </option>
                      </select>
                    </label>
                  </div>

                  <div className="option-grid">
                    {[
                      {
                        key: "balcony",
                        label: "Balkon",
                        icon: "🌤️",
                      },
                      {
                        key: "cellar",
                        label: "Keller",
                        icon: "📦",
                      },
                      {
                        key: "garage",
                        label: "Garage",
                        icon: "🚗",
                      },
                      {
                        key: "blinds",
                        label: "Lamellenstoren",
                        icon: "🪟",
                      },
                      {
                        key:
                          "handoverGuarantee",
                        label:
                          "Abgabegarantie",
                        icon: "✓",
                      },
                      {
                        key: "pets",
                        label: "Haustiere",
                        icon: "🐾",
                      },
                    ].map((option) => {
                      const key =
                        option.key as
                          | "balcony"
                          | "cellar"
                          | "garage"
                          | "blinds"
                          | "handoverGuarantee"
                          | "pets";

                      return (
                        <button
                          key={option.key}
                          type="button"
                          className={[
                            "option-card",
                            data[key]
                              ? "option-card-selected"
                              : "",
                          ].join(" ")}
                          onClick={() =>
                            updateField(
                              key,
                              !data[key],
                            )
                          }
                        >
                          <span>
                            {option.icon}
                          </span>

                          <strong>
                            {option.label}
                          </strong>

                          <small>
                            {data[key]
                              ? "Ausgewählt"
                              : "Nicht ausgewählt"}
                          </small>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ) : null}

              {isMovingService(
                data.service,
              ) ? (
                <div className="wizard-card">
                  <div className="field-grid">
                    <label>
                      <span>
                        Abholadresse
                      </span>

                      <input
                        value={data.movingFrom}
                        placeholder="Strasse, PLZ und Ort"
                        onChange={(event) =>
                          updateField(
                            "movingFrom",
                            event.target.value,
                          )
                        }
                      />
                    </label>

                    <label>
                      <span>
                        Zieladresse
                      </span>

                      <input
                        value={data.movingTo}
                        placeholder="Strasse, PLZ und Ort"
                        onChange={(event) =>
                          updateField(
                            "movingTo",
                            event.target.value,
                          )
                        }
                      />
                    </label>

                    <label>
                      <span>
                        Etage Abholort
                      </span>

                      <input
                        value={
                          data.movingFromFloor
                        }
                        placeholder="z. B. 3. Etage"
                        onChange={(event) =>
                          updateField(
                            "movingFromFloor",
                            event.target.value,
                          )
                        }
                      />
                    </label>

                    <label>
                      <span>
                        Etage Zielort
                      </span>

                      <input
                        value={
                          data.movingToFloor
                        }
                        placeholder="z. B. 1. Etage"
                        onChange={(event) =>
                          updateField(
                            "movingToFloor",
                            event.target.value,
                          )
                        }
                      />
                    </label>

                    <label>
                      <span>
                        Lift am Abholort
                      </span>

                      <select
                        value={
                          data.movingFromElevator
                        }
                        onChange={(event) =>
                          updateField(
                            "movingFromElevator",
                            event.target.value,
                          )
                        }
                      >
                        <option value="">
                          Bitte wählen
                        </option>
                        <option value="Ja">
                          Ja
                        </option>
                        <option value="Nein">
                          Nein
                        </option>
                      </select>
                    </label>

                    <label>
                      <span>
                        Lift am Zielort
                      </span>

                      <select
                        value={
                          data.movingToElevator
                        }
                        onChange={(event) =>
                          updateField(
                            "movingToElevator",
                            event.target.value,
                          )
                        }
                      >
                        <option value="">
                          Bitte wählen
                        </option>
                        <option value="Ja">
                          Ja
                        </option>
                        <option value="Nein">
                          Nein
                        </option>
                      </select>
                    </label>
                  </div>

                  <div className="option-grid option-grid-three">
                    {[
                      {
                        key: "assembly",
                        label:
                          "Montage / Demontage",
                        icon: "🛠️",
                      },
                      {
                        key: "packing",
                        label:
                          "Verpackungsservice",
                        icon: "📦",
                      },
                      {
                        key: "disposal",
                        label: "Entsorgung",
                        icon: "♻️",
                      },
                    ].map((option) => {
                      const key =
                        option.key as
                          | "assembly"
                          | "packing"
                          | "disposal";

                      return (
                        <button
                          key={option.key}
                          type="button"
                          className={[
                            "option-card",
                            data[key]
                              ? "option-card-selected"
                              : "",
                          ].join(" ")}
                          onClick={() =>
                            updateField(
                              key,
                              !data[key],
                            )
                          }
                        >
                          <span>
                            {option.icon}
                          </span>

                          <strong>
                            {option.label}
                          </strong>

                          <small>
                            {data[key]
                              ? "Gewünscht"
                              : "Nicht benötigt"}
                          </small>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ) : null}

              {data.service ===
              "Gartenpflege" ? (
                <div className="wizard-card">
                  <div className="field-grid">
                    <label>
                      <span>
                        Gartenfläche in m²
                      </span>

                      <input
                        value={data.gardenArea}
                        inputMode="numeric"
                        placeholder="z. B. 350"
                        onChange={(event) =>
                          updateField(
                            "gardenArea",
                            event.target.value,
                          )
                        }
                      />
                    </label>

                    <label>
                      <span>Objektart</span>

                      <select
                        value={data.objectType}
                        onChange={(event) =>
                          updateField(
                            "objectType",
                            event.target.value,
                          )
                        }
                      >
                        <option value="">
                          Bitte wählen
                        </option>
                        <option value="Privatgarten">
                          Privatgarten
                        </option>
                        <option value="Mehrfamilienhaus">
                          Mehrfamilienhaus
                        </option>
                        <option value="Gewerbeareal">
                          Gewerbeareal
                        </option>
                      </select>
                    </label>
                  </div>

                  <div className="option-grid">
                    {[
                      {
                        key: "lawn",
                        label: "Rasenpflege",
                        icon: "🌱",
                      },
                      {
                        key: "hedge",
                        label: "Heckenschnitt",
                        icon: "🌿",
                      },
                      {
                        key: "trees",
                        label: "Baumarbeiten",
                        icon: "🌳",
                      },
                      {
                        key: "recurring",
                        label:
                          "Wiederkehrend",
                        icon: "🔄",
                      },
                    ].map((option) => {
                      const key =
                        option.key as
                          | "lawn"
                          | "hedge"
                          | "trees"
                          | "recurring";

                      return (
                        <button
                          key={option.key}
                          type="button"
                          className={[
                            "option-card",
                            data[key]
                              ? "option-card-selected"
                              : "",
                          ].join(" ")}
                          onClick={() =>
                            updateField(
                              key,
                              !data[key],
                            )
                          }
                        >
                          <span>
                            {option.icon}
                          </span>

                          <strong>
                            {option.label}
                          </strong>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ) : null}

              {data.service ===
              "Malerarbeiten" ? (
                <div className="wizard-card">
                  <div className="field-grid">
                    <label>
                      <span>
                        Art der Arbeiten
                      </span>

                      <select
                        value={
                          data.paintingType
                        }
                        onChange={(event) =>
                          updateField(
                            "paintingType",
                            event.target.value,
                          )
                        }
                      >
                        <option value="">
                          Bitte wählen
                        </option>
                        <option value="Innenanstrich">
                          Innenanstrich
                        </option>
                        <option value="Aussenanstrich">
                          Aussenanstrich
                        </option>
                        <option value="Fassade">
                          Fassade
                        </option>
                        <option value="Renovation">
                          Renovation
                        </option>
                      </select>
                    </label>

                    <label>
                      <span>
                        Anzahl Räume
                      </span>

                      <input
                        value={
                          data.paintingRooms
                        }
                        placeholder="z. B. 4"
                        onChange={(event) =>
                          updateField(
                            "paintingRooms",
                            event.target.value,
                          )
                        }
                      />
                    </label>

                    <label>
                      <span>
                        Fläche in m²
                      </span>

                      <input
                        value={
                          data.paintingArea
                        }
                        inputMode="numeric"
                        placeholder="z. B. 120"
                        onChange={(event) =>
                          updateField(
                            "paintingArea",
                            event.target.value,
                          )
                        }
                      />
                    </label>
                  </div>
                </div>
              ) : null}

              {data.service ===
              "Elektriker" ? (
                <div className="wizard-card">
                  <label>
                    <span>
                      Welche Arbeit wird benötigt?
                    </span>

                    <select
                      value={
                        data.electricalType
                      }
                      onChange={(event) =>
                        updateField(
                          "electricalType",
                          event.target.value,
                        )
                      }
                    >
                      <option value="">
                        Bitte wählen
                      </option>
                      <option value="Elektroinstallation">
                        Elektroinstallation
                      </option>
                      <option value="Steckdosen und Schalter">
                        Steckdosen und Schalter
                      </option>
                      <option value="Lampenmontage">
                        Lampenmontage
                      </option>
                      <option value="Sicherungskasten">
                        Sicherungskasten
                      </option>
                      <option value="Störung oder Reparatur">
                        Störung oder Reparatur
                      </option>
                      <option value="Neubau oder Umbau">
                        Neubau oder Umbau
                      </option>
                    </select>
                  </label>
                </div>
              ) : null}

              {data.service ===
              "Sanitär" ? (
                <div className="wizard-card">
                  <label>
                    <span>
                      Welche Sanitärarbeit wird benötigt?
                    </span>

                    <select
                      value={
                        data.sanitaryType
                      }
                      onChange={(event) =>
                        updateField(
                          "sanitaryType",
                          event.target.value,
                        )
                      }
                    >
                      <option value="">
                        Bitte wählen
                      </option>
                      <option value="Bad oder Dusche">
                        Bad oder Dusche
                      </option>
                      <option value="WC">
                        WC
                      </option>
                      <option value="Wasserleitung">
                        Wasserleitung
                      </option>
                      <option value="Boiler">
                        Boiler
                      </option>
                      <option value="Armaturen">
                        Armaturen
                      </option>
                      <option value="Verstopfung oder Störung">
                        Verstopfung oder Störung
                      </option>
                    </select>
                  </label>
                </div>
              ) : null}

              <div className="wizard-card description-card">
                <label>
                  <span>
                    Beschreibe deinen Auftrag *
                  </span>

                  <textarea
                    value={data.message}
                    placeholder="Was soll genau gemacht werden? Welche Besonderheiten gibt es? Je genauer deine Angaben sind, desto besser können Anbieter den Auftrag einschätzen."
                    onChange={(event) =>
                      updateField(
                        "message",
                        event.target.value,
                      )
                    }
                  />
                </label>

                <div className="description-help">
                  <span>💡</span>

                  <p>
                    Erwähne beispielsweise Zustand,
                    Zugänglichkeit, besondere Wünsche
                    oder vorhandene Schäden.
                  </p>
                </div>
              </div>
            </section>
          ) : null}

          {step === 4 ? (
            <section>
              <p className="wizard-kicker">
                Ausführung
              </p>

              <h2>
                Wann soll der
                <span> Auftrag stattfinden?</span>
              </h2>

              <p className="wizard-description">
                Wähle einen Zeitraum oder gib
                direkt dein Wunschdatum an.
              </p>

              <div className="urgency-grid">
                {[
                  {
                    value: "So schnell wie möglich",
                    label:
                      "So schnell wie möglich",
                    icon: "⚡",
                  },
                  {
                    value: "Innerhalb einer Woche",
                    label:
                      "Innerhalb einer Woche",
                    icon: "📅",
                  },
                  {
                    value: "Innerhalb eines Monats",
                    label:
                      "Innerhalb eines Monats",
                    icon: "🗓️",
                  },
                  {
                    value: "Flexibel",
                    label: "Flexibel",
                    icon: "🔄",
                  },
                ].map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    className={[
                      "urgency-card",
                      data.urgency ===
                      option.value
                        ? "urgency-card-selected"
                        : "",
                    ].join(" ")}
                    onClick={() => {
                      updateField(
                        "urgency",
                        option.value,
                      );

                      if (
                        option.value ===
                        "Flexibel"
                      ) {
                        updateField(
                          "flexibleDate",
                          true,
                        );
                      }
                    }}
                  >
                    <span>
                      {option.icon}
                    </span>

                    <strong>
                      {option.label}
                    </strong>
                  </button>
                ))}
              </div>

              <div className="wizard-card date-card">
                <label>
                  <span>
                    Oder konkretes Wunschdatum
                  </span>

                  <input
                    type="date"
                    value={data.desiredDate}
                    onChange={(event) =>
                      updateField(
                        "desiredDate",
                        event.target.value,
                      )
                    }
                  />
                </label>

                <button
                  type="button"
                  className={[
                    "flexible-toggle",
                    data.flexibleDate
                      ? "flexible-toggle-active"
                      : "",
                  ].join(" ")}
                  onClick={() =>
                    updateField(
                      "flexibleDate",
                      !data.flexibleDate,
                    )
                  }
                >
                  <span>
                    {data.flexibleDate
                      ? "✓"
                      : ""}
                  </span>

                  Termin ist flexibel
                </button>
              </div>
            </section>
          ) : null}

          {step === 5 ? (
            <section>
              <p className="wizard-kicker">
                Kontaktdaten
              </p>

              <h2>
                Wie können Anbieter
                <span> dich erreichen?</span>
              </h2>

              <p className="wizard-description">
                Deine Kontaktdaten werden nur
                für die Bearbeitung deiner
                Anfrage verwendet.
              </p>

              <div className="wizard-card contact-card">
                <div className="field-grid">
                  <label>
                    <span>
                      Vorname und Name *
                    </span>

                    <input
                      value={data.name}
                      autoComplete="name"
                      placeholder="Max Muster"
                      onChange={(event) =>
                        updateField(
                          "name",
                          event.target.value,
                        )
                      }
                    />
                  </label>

                  <label>
                    <span>
                      Telefonnummer *
                    </span>

                    <input
                      value={data.phone}
                      type="tel"
                      autoComplete="tel"
                      placeholder="+41 79 123 45 67"
                      onChange={(event) =>
                        updateField(
                          "phone",
                          event.target.value,
                        )
                      }
                    />
                  </label>

                  <label className="field-full">
                    <span>
                      E-Mail-Adresse *
                    </span>

                    <input
                      value={data.email}
                      type="email"
                      autoComplete="email"
                      placeholder="max@beispiel.ch"
                      onChange={(event) =>
                        updateField(
                          "email",
                          event.target.value,
                        )
                      }
                    />
                  </label>
                </div>

                <label className="privacy-check">
                  <input
                    type="checkbox"
                    checked={
                      data.privacyAccepted
                    }
                    onChange={(event) =>
                      updateField(
                        "privacyAccepted",
                        event.target.checked,
                      )
                    }
                  />

                  <span>
                    Ich stimme zu, dass meine
                    Angaben zur Vermittlung
                    passender Anbieter verarbeitet
                    werden. *
                  </span>
                </label>

                <div className="contact-trust">
                  <div>
                    <span>🔒</span>

                    <p>
                      <strong>
                        Sichere Übermittlung
                      </strong>

                      <small>
                        Verschlüsselte Verbindung
                      </small>
                    </p>
                  </div>

                  <div>
                    <span>🇨🇭</span>

                    <p>
                      <strong>
                        Schweizer Plattform
                      </strong>

                      <small>
                        Regionale Dienstleister
                      </small>
                    </p>
                  </div>
                </div>
              </div>
            </section>
          ) : null}

          {step === 6 ? (
            <section>
              <p className="wizard-kicker">
                Fast geschafft
              </p>

              <h2>
                Prüfe deine
                <span> Anfrage.</span>
              </h2>

              <p className="wizard-description">
                Kontrolliere die wichtigsten
                Angaben und sende deine Anfrage
                anschliessend kostenlos ab.
              </p>

              <div className="summary-grid">
                <article>
                  <span>
                    Dienstleistung
                  </span>

                  <div className="summary-service">
                    <i>
                      {selectedService?.icon ||
                        "✓"}
                    </i>

                    <strong>
                      {data.service}
                    </strong>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      setStep(1)
                    }
                  >
                    Ändern
                  </button>
                </article>

                <article>
                  <span>
                    Standort
                  </span>

                  <strong>
                    {data.postalCode}{" "}
                    {data.city}
                  </strong>

                  <button
                    type="button"
                    onClick={() =>
                      setStep(2)
                    }
                  >
                    Ändern
                  </button>
                </article>

                <article>
                  <span>
                    Termin
                  </span>

                  <strong>
                    {data.desiredDate ||
                      data.urgency ||
                      "Nach Absprache"}
                  </strong>

                  <button
                    type="button"
                    onClick={() =>
                      setStep(4)
                    }
                  >
                    Ändern
                  </button>
                </article>

                <article>
                  <span>
                    Kontakt
                  </span>

                  <strong>
                    {data.name}
                  </strong>

                  <small>
                    {data.email}
                    <br />
                    {data.phone}
                  </small>

                  <button
                    type="button"
                    onClick={() =>
                      setStep(5)
                    }
                  >
                    Ändern
                  </button>
                </article>
              </div>

              <div className="summary-description">
                <span>
                  Auftragsbeschreibung
                </span>

                <p>
                  {data.message}
                </p>

                <button
                  type="button"
                  onClick={() =>
                    setStep(3)
                  }
                >
                  Beschreibung bearbeiten
                </button>
              </div>

              <div className="final-trust">
                <span>
                  ✓ Kostenlos
                </span>

                <span>
                  ✓ Unverbindlich
                </span>

                <span>
                  ✓ Keine Annahmepflicht
                </span>

                <span>
                  ✓ Regionale Anbieter
                </span>
              </div>
            </section>
          ) : null}
        </div>

        {error ? (
          <div
            className="wizard-error"
            role="alert"
          >
            <span>!</span>
            {error}
          </div>
        ) : null}

        <div className="wizard-navigation">
          {step > 1 ? (
            <button
              type="button"
              className="wizard-back"
              onClick={goBack}
              disabled={sending}
            >
              ← Zurück
            </button>
          ) : (
            <span />
          )}

          {step < STEPS.length ? (
            <button
              type="button"
              className="wizard-next"
              onClick={goNext}
            >
              Weiter
              <span>→</span>
            </button>
          ) : (
            <button
              type="submit"
              className="wizard-submit"
              disabled={sending}
            >
              {sending
                ? "Anfrage wird gesendet..."
                : "Kostenlose Anfrage absenden"}

              {!sending ? (
                <span>→</span>
              ) : null}
            </button>
          )}
        </div>

        <div className="wizard-security">
          <span>🔒</span>

          Deine Daten werden verschlüsselt
          übertragen und nur zur Vermittlung
          passender Anbieter verwendet.
        </div>
      </form>

      <style jsx>{`
        .premium-wizard {
          position: relative;
          width: 100%;
          color: #f8fafc;
        }

        .wizard-progress-top {
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          gap: 20px;
        }

        .wizard-progress-top > div {
          display: grid;
          gap: 4px;
        }

        .wizard-progress-top span {
          color: #7dd3fc;
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.13em;
          text-transform: uppercase;
        }

        .wizard-progress-top strong {
          color: white;
          font-size: 17px;
        }

        .progress-percent {
          color: #94a3b8 !important;
        }

        .progress-track {
          height: 7px;
          margin-top: 14px;
          overflow: hidden;
          border-radius: 999px;
          background: rgba(255, 255, 255, 0.065);
        }

        .progress-fill {
          height: 100%;
          border-radius: inherit;
          background:
            linear-gradient(
              90deg,
              #38bdf8,
              #6366f1,
              #c026d3
            );
          box-shadow:
            0 0 24px rgba(99, 102, 241, 0.5);
          transition: width 450ms cubic-bezier(.2,.8,.2,1);
        }

        .wizard-step-dots {
          display: grid;
          grid-template-columns: repeat(6, 1fr);
          gap: 7px;
          margin-top: 18px;
        }

        .wizard-step-dot {
          display: grid;
          gap: 6px;
          place-items: center;
          padding: 0;
          border: 0;
          color: #64748b;
          background: transparent;
          cursor: default;
        }

        .wizard-step-dot > span {
          display: grid;
          width: 29px;
          height: 29px;
          place-items: center;
          border: 1px solid rgba(255,255,255,.09);
          border-radius: 50%;
          background: rgba(255,255,255,.025);
          font-size: 9px;
          font-weight: 900;
        }

        .wizard-step-dot small {
          font-size: 8px;
          font-weight: 800;
        }

        .wizard-step-dot-complete {
          color: #86efac;
          cursor: pointer;
        }

        .wizard-step-dot-complete > span {
          border-color: rgba(74, 222, 128, 0.25);
          background: rgba(34, 197, 94, 0.1);
        }

        .wizard-step-dot-active {
          color: #7dd3fc;
        }

        .wizard-step-dot-active > span {
          border-color: rgba(56, 189, 248, 0.4);
          background:
            linear-gradient(
              135deg,
              rgba(56,189,248,.25),
              rgba(99,102,241,.2)
            );
          box-shadow:
            0 0 22px rgba(56, 189, 248, 0.17);
        }

        .wizard-content {
          min-height: 540px;
          padding-top: 38px;
          animation:
            wizardEnter 420ms cubic-bezier(.2,.8,.2,1);
        }

        .wizard-kicker {
          margin: 0;
          color: #7dd3fc;
          font-size: 10px;
          font-weight: 900;
          letter-spacing: 0.18em;
          text-transform: uppercase;
        }

        h2 {
          margin: 12px 0 0;
          color: white;
          font-size: clamp(31px, 4vw, 45px);
          line-height: 1.01;
          letter-spacing: -0.055em;
        }

        h2 span {
          color: transparent;
          background:
            linear-gradient(
              90deg,
              #38bdf8,
              #818cf8,
              #d946ef
            );
          background-clip: text;
          -webkit-background-clip: text;
        }

        .wizard-description {
          max-width: 620px;
          margin: 15px 0 0;
          color: #94a3b8;
          font-size: 13px;
          line-height: 1.7;
        }

        .service-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 11px;
          margin-top: 28px;
        }

        .service-card {
          position: relative;
          display: flex;
          min-height: 145px;
          flex-direction: column;
          align-items: flex-start;
          overflow: hidden;
          padding: 17px;
          border: 1px solid rgba(255,255,255,.085);
          border-radius: 19px;
          color: #f8fafc;
          background:
            linear-gradient(
              145deg,
              rgba(255,255,255,.045),
              rgba(255,255,255,.015)
            );
          text-align: left;
          cursor: pointer;
          transition:
            transform 180ms ease,
            border-color 180ms ease,
            background 180ms ease,
            box-shadow 180ms ease;
        }

        .service-card::before {
          content: "";
          position: absolute;
          top: -65px;
          right: -60px;
          width: 125px;
          height: 125px;
          border-radius: 50%;
          background: rgba(56, 189, 248, 0.07);
          filter: blur(25px);
        }

        .service-card:hover {
          transform: translateY(-4px);
          border-color: rgba(125, 211, 252, 0.3);
          background: rgba(56, 189, 248, 0.055);
          box-shadow: 0 18px 40px rgba(0,0,0,.2);
        }

        .service-card-selected {
          border-color: rgba(99, 102, 241, 0.55);
          background:
            linear-gradient(
              145deg,
              rgba(56,189,248,.13),
              rgba(99,102,241,.13)
            );
          box-shadow:
            0 18px 45px rgba(79,70,229,.16),
            inset 0 1px 0 rgba(255,255,255,.08);
        }

        .service-icon {
          display: grid;
          width: 43px;
          height: 43px;
          place-items: center;
          border: 1px solid rgba(255,255,255,.09);
          border-radius: 13px;
          background: rgba(0,0,0,.2);
          font-size: 21px;
        }

        .service-card strong {
          margin-top: 14px;
          font-size: 13px;
        }

        .service-card small {
          margin-top: 5px;
          padding-right: 20px;
          color: #718096;
          font-size: 9px;
          line-height: 1.45;
        }

        .service-check {
          position: absolute;
          right: 14px;
          bottom: 14px;
          color: #7dd3fc;
          font-size: 13px;
          font-weight: 900;
        }

        .wizard-card {
          margin-top: 27px;
          padding: 22px;
          border: 1px solid rgba(255,255,255,.085);
          border-radius: 23px;
          background:
            linear-gradient(
              145deg,
              rgba(255,255,255,.04),
              rgba(255,255,255,.014)
            );
          box-shadow:
            inset 0 1px 0 rgba(255,255,255,.025);
        }

        .location-icon {
          display: grid;
          width: 53px;
          height: 53px;
          place-items: center;
          margin-bottom: 18px;
          border: 1px solid rgba(56, 189, 248, 0.19);
          border-radius: 17px;
          background: rgba(56, 189, 248, 0.07);
          font-size: 24px;
        }

        .field-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 14px;
        }

        label {
          display: grid;
          gap: 8px;
        }

        label > span {
          color: #bac5d4;
          font-size: 10px;
          font-weight: 800;
        }

        input,
        select,
        textarea {
          width: 100%;
          min-height: 52px;
          padding: 13px 15px;
          border: 1px solid rgba(255,255,255,.11);
          border-radius: 14px;
          outline: none;
          color: #f8fafc;
          background: rgba(1, 5, 19, .78);
          font: inherit;
          font-size: 12px;
          transition:
            border-color 160ms ease,
            box-shadow 160ms ease,
            background 160ms ease;
        }

        input::placeholder,
        textarea::placeholder {
          color: #56647a;
        }

        select option {
          color: #0f172a;
          background: white;
        }

        input:focus,
        select:focus,
        textarea:focus {
          border-color: rgba(96, 165, 250, 0.65);
          background: rgba(4, 10, 30, 0.95);
          box-shadow:
            0 0 0 4px rgba(59,130,246,.09);
        }

        textarea {
          min-height: 145px;
          resize: vertical;
          line-height: 1.65;
        }

        .location-confirmation {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-top: 17px;
          padding: 13px;
          border: 1px solid rgba(74,222,128,.17);
          border-radius: 14px;
          background: rgba(34,197,94,.065);
        }

        .location-confirmation > span {
          display: grid;
          width: 31px;
          height: 31px;
          place-items: center;
          border-radius: 50%;
          color: #86efac;
          background: rgba(34,197,94,.1);
          font-size: 10px;
          font-weight: 900;
        }

        .location-confirmation div {
          display: grid;
          gap: 3px;
        }

        .location-confirmation strong {
          font-size: 11px;
        }

        .location-confirmation small {
          color: #77a28a;
          font-size: 9px;
        }

        .option-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 9px;
          margin-top: 18px;
        }

        .option-card {
          display: grid;
          min-height: 100px;
          place-items: center;
          align-content: center;
          gap: 6px;
          padding: 12px;
          border: 1px solid rgba(255,255,255,.075);
          border-radius: 15px;
          color: #cbd5e1;
          background: rgba(255,255,255,.025);
          text-align: center;
          cursor: pointer;
        }

        .option-card > span {
          font-size: 18px;
        }

        .option-card strong {
          font-size: 10px;
        }

        .option-card small {
          color: #64748b;
          font-size: 7px;
        }

        .option-card-selected {
          border-color: rgba(74,222,128,.28);
          color: #dcfce7;
          background: rgba(34,197,94,.075);
        }

        .description-card {
          margin-top: 14px;
        }

        .description-help {
          display: flex;
          gap: 10px;
          margin-top: 13px;
          color: #718096;
          font-size: 9px;
          line-height: 1.55;
        }

        .description-help p {
          margin: 0;
        }

        .urgency-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
          margin-top: 27px;
        }

        .urgency-card {
          display: flex;
          min-height: 100px;
          align-items: center;
          gap: 14px;
          padding: 17px;
          border: 1px solid rgba(255,255,255,.085);
          border-radius: 18px;
          color: #dbe5f1;
          background: rgba(255,255,255,.027);
          cursor: pointer;
          text-align: left;
        }

        .urgency-card > span {
          display: grid;
          width: 42px;
          height: 42px;
          flex-shrink: 0;
          place-items: center;
          border-radius: 13px;
          background: rgba(56,189,248,.07);
          font-size: 20px;
        }

        .urgency-card strong {
          font-size: 11px;
        }

        .urgency-card-selected {
          border-color: rgba(99,102,241,.45);
          background:
            linear-gradient(
              145deg,
              rgba(56,189,248,.1),
              rgba(99,102,241,.1)
            );
        }

        .date-card {
          display: grid;
          grid-template-columns: 1fr auto;
          align-items: end;
          gap: 15px;
        }

        .flexible-toggle {
          display: flex;
          min-height: 52px;
          align-items: center;
          gap: 9px;
          padding: 11px 14px;
          border: 1px solid rgba(255,255,255,.085);
          border-radius: 14px;
          color: #aeb9c9;
          background: rgba(255,255,255,.025);
          font-size: 10px;
          font-weight: 800;
          cursor: pointer;
        }

        .flexible-toggle > span {
          display: grid;
          width: 21px;
          height: 21px;
          place-items: center;
          border: 1px solid rgba(255,255,255,.12);
          border-radius: 7px;
          font-size: 8px;
        }

        .flexible-toggle-active {
          border-color: rgba(74,222,128,.25);
          color: #bbf7d0;
          background: rgba(34,197,94,.07);
        }

        .contact-card {
          margin-top: 27px;
        }

        .field-full {
          grid-column: 1 / -1;
        }

        .privacy-check {
          display: flex;
          align-items: flex-start;
          gap: 11px;
          margin-top: 18px;
          color: #8d9bad;
          font-size: 9px;
          line-height: 1.55;
        }

        .privacy-check input {
          width: 19px;
          min-height: 19px;
          flex-shrink: 0;
          margin: 0;
          padding: 0;
          accent-color: #6366f1;
        }

        .privacy-check > span {
          color: #8d9bad;
          font-weight: 650;
        }

        .contact-trust {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 10px;
          margin-top: 20px;
          padding-top: 18px;
          border-top: 1px solid rgba(255,255,255,.07);
        }

        .contact-trust > div {
          display: flex;
          align-items: center;
          gap: 11px;
          padding: 12px;
          border-radius: 14px;
          background: rgba(255,255,255,.02);
        }

        .contact-trust > div > span {
          font-size: 18px;
        }

        .contact-trust p {
          display: grid;
          gap: 3px;
          margin: 0;
        }

        .contact-trust strong {
          font-size: 9px;
        }

        .contact-trust small {
          color: #64748b;
          font-size: 7px;
        }

        .summary-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 11px;
          margin-top: 27px;
        }

        .summary-grid article,
        .summary-description {
          position: relative;
          min-height: 130px;
          padding: 17px;
          border: 1px solid rgba(255,255,255,.085);
          border-radius: 18px;
          background: rgba(255,255,255,.025);
        }

        .summary-grid article > span,
        .summary-description > span {
          display: block;
          color: #6f7d91;
          font-size: 8px;
          font-weight: 900;
          letter-spacing: 0.1em;
          text-transform: uppercase;
        }

        .summary-grid article > strong {
          display: block;
          margin-top: 18px;
          font-size: 13px;
        }

        .summary-grid article > small {
          display: block;
          margin-top: 5px;
          color: #718096;
          font-size: 8px;
          line-height: 1.55;
        }

        .summary-grid button,
        .summary-description button {
          position: absolute;
          right: 14px;
          bottom: 13px;
          padding: 0;
          border: 0;
          color: #7dd3fc;
          background: transparent;
          font-size: 8px;
          font-weight: 900;
          cursor: pointer;
        }

        .summary-service {
          display: flex;
          align-items: center;
          gap: 9px;
          margin-top: 16px;
        }

        .summary-service i {
          font-style: normal;
          font-size: 20px;
        }

        .summary-service strong {
          font-size: 13px;
        }

        .summary-description {
          min-height: 150px;
          margin-top: 11px;
        }

        .summary-description p {
          margin: 15px 0 30px;
          color: #a6b1c1;
          font-size: 10px;
          line-height: 1.65;
          white-space: pre-wrap;
        }

        .final-trust {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          margin-top: 14px;
        }

        .final-trust span {
          padding: 8px 10px;
          border: 1px solid rgba(74,222,128,.13);
          border-radius: 999px;
          color: #9ae6b4;
          background: rgba(34,197,94,.045);
          font-size: 8px;
          font-weight: 800;
        }

        .wizard-error {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-top: 15px;
          padding: 13px 15px;
          border: 1px solid rgba(248,113,113,.22);
          border-radius: 14px;
          color: #fecaca;
          background: rgba(239,68,68,.075);
          font-size: 10px;
          font-weight: 750;
        }

        .wizard-error span {
          display: grid;
          width: 24px;
          height: 24px;
          place-items: center;
          border-radius: 50%;
          background: rgba(239,68,68,.12);
          font-weight: 900;
        }

        .wizard-navigation {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 13px;
          margin-top: 24px;
          padding-top: 20px;
          border-top: 1px solid rgba(255,255,255,.07);
        }

        .wizard-back,
        .wizard-next,
        .wizard-submit {
          display: inline-flex;
          min-height: 55px;
          align-items: center;
          justify-content: center;
          gap: 13px;
          padding: 13px 21px;
          border-radius: 15px;
          font: inherit;
          font-size: 11px;
          font-weight: 900;
          cursor: pointer;
        }

        .wizard-back {
          border: 1px solid rgba(255,255,255,.09);
          color: #cbd5e1;
          background: rgba(255,255,255,.03);
        }

        .wizard-next,
        .wizard-submit {
          min-width: 180px;
          border: 1px solid rgba(125,211,252,.3);
          color: white;
          background:
            linear-gradient(
              95deg,
              #38bdf8,
              #6366f1,
              #c026d3
            );
          box-shadow:
            0 18px 50px rgba(79,70,229,.27);
        }

        .wizard-submit {
          min-width: 260px;
        }

        .wizard-next:hover,
        .wizard-submit:hover {
          transform: translateY(-2px);
        }

        .wizard-submit:disabled {
          cursor: wait;
          opacity: 0.7;
        }

        .wizard-security {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          margin-top: 17px;
          color: #65738a;
          font-size: 8px;
          text-align: center;
        }

        .quote-wizard-success {
          display: grid;
          min-height: 650px;
          place-content: center;
          padding: 45px 10px;
          text-align: center;
          animation:
            wizardEnter 500ms cubic-bezier(.2,.8,.2,1);
        }

        .quote-success-orbit {
          position: relative;
          display: grid;
          width: 105px;
          height: 105px;
          place-items: center;
          margin: 0 auto;
          border: 1px solid rgba(74,222,128,.24);
          border-radius: 50%;
          background:
            radial-gradient(
              circle,
              rgba(34,197,94,.16),
              rgba(34,197,94,.035)
            );
          box-shadow:
            0 0 70px rgba(34,197,94,.17);
        }

        .quote-success-orbit::before {
          content: "";
          position: absolute;
          inset: -11px;
          border: 1px dashed rgba(74,222,128,.16);
          border-radius: 50%;
          animation: successRotate 14s linear infinite;
        }

        .quote-success-orbit span {
          display: grid;
          width: 55px;
          height: 55px;
          place-items: center;
          border-radius: 50%;
          color: #052e16;
          background: #86efac;
          font-size: 24px;
          font-weight: 900;
        }

        .quote-wizard-success .wizard-kicker {
          margin-top: 28px;
          color: #86efac;
        }

        .quote-wizard-success h2 {
          margin-top: 13px;
        }

        .quote-success-description {
          max-width: 560px;
          margin: 17px auto 0;
          color: #94a3b8;
          font-size: 12px;
          line-height: 1.75;
        }

        .quote-quote-success-steps {
          display: grid;
          max-width: 570px;
          gap: 9px;
          margin: 28px auto 0;
          text-align: left;
        }

        .quote-success-step {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 13px;
          border: 1px solid rgba(255,255,255,.075);
          border-radius: 14px;
          background: rgba(255,255,255,.025);
        }

        .quote-success-step > span {
          display: grid;
          width: 33px;
          height: 33px;
          flex-shrink: 0;
          place-items: center;
          border-radius: 50%;
          font-size: 10px;
          font-weight: 900;
        }

        .quote-success-step div {
          display: grid;
          gap: 3px;
        }

        .quote-success-step strong {
          font-size: 10px;
        }

        .quote-success-step small {
          color: #6f7d91;
          font-size: 8px;
        }

        .quote-success-complete > span {
          color: #86efac;
          background: rgba(34,197,94,.1);
        }

        .quote-success-active {
          border-color: rgba(56,189,248,.18);
        }

        .quote-success-active > span {
          color: #7dd3fc;
          background: rgba(56,189,248,.09);
          animation: activePulse 1.8s ease-in-out infinite;
        }

        .quote-success-summary {
          display: grid;
          max-width: 570px;
          grid-template-columns: repeat(3, 1fr);
          gap: 9px;
          margin: 20px auto 0;
        }

        .quote-success-summary > div {
          padding: 13px;
          border: 1px solid rgba(255,255,255,.065);
          border-radius: 13px;
          background: rgba(255,255,255,.02);
        }

        .quote-success-summary span {
          display: block;
          color: #64748b;
          font-size: 7px;
          font-weight: 850;
          text-transform: uppercase;
        }

        .quote-success-summary strong {
          display: block;
          margin-top: 7px;
          font-size: 9px;
        }


        /*
         * Erfolgsmeldung:
         * eindeutige Klassen und feste Layout-Regeln,
         * damit keine globalen Projekt-Styles hineinfunken.
         */
        .quote-wizard-success {
          position: relative !important;
          display: flex !important;
          width: 100% !important;
          min-height: 620px !important;
          flex-direction: column !important;
          align-items: center !important;
          justify-content: center !important;
          padding: 48px 24px !important;
          overflow: hidden !important;
          color: #f8fafc !important;
          text-align: center !important;
        }

        .quote-success-orbit {
          position: relative !important;
          display: grid !important;
          width: 105px !important;
          height: 105px !important;
          flex: 0 0 105px !important;
          place-items: center !important;
          margin: 0 auto !important;
        }

        .quote-success-orbit > span {
          position: relative !important;
          inset: auto !important;
          display: grid !important;
          width: 56px !important;
          height: 56px !important;
          place-items: center !important;
          margin: 0 !important;
          border-radius: 999px !important;
          color: #052e16 !important;
          background: #22c55e !important;
          font-size: 27px !important;
          font-weight: 900 !important;
          line-height: 1 !important;
          transform: none !important;
        }

        .quote-wizard-success > h2 {
          position: relative !important;
          display: block !important;
          width: 100% !important;
          max-width: 680px !important;
          margin: 18px auto 0 !important;
          line-height: 1.02 !important;
          text-align: center !important;
        }

        .quote-success-description {
          position: relative !important;
          display: block !important;
          width: 100% !important;
          max-width: 620px !important;
          margin: 20px auto 0 !important;
          color: #94a3b8 !important;
          font-size: 14px !important;
          line-height: 1.75 !important;
          text-align: center !important;
        }

        .quote-success-steps {
          position: relative !important;
          display: grid !important;
          width: 100% !important;
          max-width: 620px !important;
          grid-template-columns: 1fr !important;
          gap: 11px !important;
          margin: 30px auto 0 !important;
          padding: 0 !important;
          text-align: left !important;
        }

        .quote-success-step {
          position: relative !important;
          inset: auto !important;
          display: grid !important;
          width: 100% !important;
          min-height: 74px !important;
          grid-template-columns: 42px 1fr !important;
          align-items: center !important;
          gap: 14px !important;
          margin: 0 !important;
          padding: 15px 17px !important;
          border: 1px solid rgba(255,255,255,.085) !important;
          border-radius: 16px !important;
          background: rgba(255,255,255,.027) !important;
          transform: none !important;
        }

        .quote-success-step > span {
          position: relative !important;
          inset: auto !important;
          display: grid !important;
          width: 38px !important;
          height: 38px !important;
          place-items: center !important;
          margin: 0 !important;
          border-radius: 999px !important;
          font-size: 12px !important;
          font-weight: 900 !important;
          line-height: 1 !important;
          transform: none !important;
        }

        .quote-success-step > div {
          position: relative !important;
          display: grid !important;
          width: auto !important;
          gap: 4px !important;
          margin: 0 !important;
          transform: none !important;
        }

        .quote-success-step strong {
          display: block !important;
          margin: 0 !important;
          color: #f8fafc !important;
          font-size: 12px !important;
          line-height: 1.35 !important;
        }

        .quote-success-step small {
          display: block !important;
          margin: 0 !important;
          color: #718096 !important;
          font-size: 9px !important;
          line-height: 1.5 !important;
        }

        .quote-success-complete > span {
          color: #86efac !important;
          background: rgba(34,197,94,.12) !important;
        }

        .quote-success-active {
          border-color: rgba(56,189,248,.22) !important;
          background: rgba(56,189,248,.045) !important;
        }

        .quote-success-active > span {
          color: #7dd3fc !important;
          background: rgba(56,189,248,.11) !important;
        }

        .quote-success-summary {
          position: relative !important;
          display: grid !important;
          width: 100% !important;
          max-width: 620px !important;
          grid-template-columns: repeat(3, minmax(0, 1fr)) !important;
          gap: 10px !important;
          margin: 22px auto 0 !important;
          padding: 0 !important;
        }

        .quote-success-summary > div {
          position: relative !important;
          display: block !important;
          min-width: 0 !important;
          margin: 0 !important;
          padding: 15px !important;
          border: 1px solid rgba(255,255,255,.075) !important;
          border-radius: 15px !important;
          background: rgba(255,255,255,.025) !important;
          transform: none !important;
        }

        .quote-success-summary span {
          position: relative !important;
          display: block !important;
          margin: 0 !important;
          color: #64748b !important;
          font-size: 8px !important;
          font-weight: 850 !important;
          line-height: 1.35 !important;
          text-transform: uppercase !important;
          transform: none !important;
        }

        .quote-success-summary strong {
          position: relative !important;
          display: block !important;
          margin: 8px 0 0 !important;
          color: #f8fafc !important;
          font-size: 10px !important;
          line-height: 1.45 !important;
          overflow-wrap: anywhere !important;
          transform: none !important;
        }

        @media (max-width: 620px) {
          .quote-wizard-success {
            min-height: 560px !important;
            padding: 38px 10px !important;
          }

          .quote-success-summary {
            grid-template-columns: 1fr !important;
          }
        }

        @keyframes wizardEnter {
          from {
            opacity: 0;
            transform: translateY(12px);
          }

          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes successRotate {
          to {
            transform: rotate(360deg);
          }
        }

        @keyframes activePulse {
          0%,
          100% {
            opacity: 0.55;
          }

          50% {
            opacity: 1;
          }
        }

        @media (max-width: 820px) {
          .wizard-content {
            min-height: auto;
          }

          .service-grid {
            grid-template-columns: repeat(2, 1fr);
          }

          .wizard-step-dot small {
            display: none;
          }

          .option-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }

        @media (max-width: 560px) {
          .wizard-step-dots {
            gap: 3px;
          }

          .wizard-step-dot > span {
            width: 25px;
            height: 25px;
          }

          .wizard-content {
            padding-top: 29px;
          }

          h2 {
            font-size: 32px;
          }

          .service-grid {
            grid-template-columns: 1fr 1fr;
            gap: 8px;
          }

          .service-card {
            min-height: 137px;
            padding: 14px;
          }

          .field-grid,
          .urgency-grid,
          .date-card,
          .contact-trust,
          .summary-grid,
          .quote-success-summary {
            grid-template-columns: 1fr;
          }

          .field-full {
            grid-column: auto;
          }

          .wizard-card {
            padding: 17px;
          }

          .wizard-navigation {
            align-items: stretch;
            flex-direction: column-reverse;
          }

          .wizard-navigation > span {
            display: none;
          }

          .wizard-back,
          .wizard-next,
          .wizard-submit {
            width: 100%;
          }

          .wizard-submit {
            min-width: 0;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .wizard-content,
          .quote-wizard-success,
          .quote-success-orbit::before,
          .quote-success-active > span {
            animation: none !important;
          }
        }
      `}</style>
    </>
  );
}
